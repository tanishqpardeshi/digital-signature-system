export type AlgorithmType = 'Ed25519' | 'RSA-2048';
export type PayloadType = 'text' | 'file';

export interface KeyPair {
  algorithm: AlgorithmType;
  private_pem: string;
  public_pem: string;
  fingerprint_sha256: string;
  encrypted: boolean;
  created_at: string;
}

export interface SignatureBundleData {
  algorithm: AlgorithmType;
  signature_b64: string;
  payload_sha256: string;
  public_key_fingerprint: string;
  signed_at: string;
  payload_type: PayloadType;
  filename: string | null;
}

export interface VerificationResult {
  is_valid: boolean;
  algorithm: string;
  payload_sha256: string;
  public_key_fingerprint: string;
  reason: string;
}

export interface ActivityLogEntry {
  id: string;
  time_utc: string;
  action: string;
  algorithm: string;
  key_fingerprint: string;
  status: string;
}

export interface ProjectSourceFile {
  path: string;
  filename: string;
  content: string;
  lines: number;
  bytes: number;
}

export type ActiveTabId = 'keys' | 'sign' | 'verify' | 'architecture' | 'streamlit-code';

export const SAMPLE_INVOICE_TEXT = [
  'INVOICE #INV-2026-0842',
  'From: Aegis Cloud Security Ltd.',
  'To: Meridian Financial Holdings',
  'Amount Due: $48,500.00 USD',
  'Settlement IBAN: DE89-3704-0044-0532-0130-00',
  'Authorized By: Chief Information Security Officer',
  'Terms: Net-15 Wire Transfer — Immutable Cryptographic Audit Record',
].join('\n');
