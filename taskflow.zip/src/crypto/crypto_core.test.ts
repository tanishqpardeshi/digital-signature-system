import test from 'node:test';
import assert from 'node:assert/strict';
import {
  SignatureBundle,
  computeSha256Hex,
  generateKeypair,
  publicKeyFingerprint,
  signBytes,
  verifyBytes,
} from './crypto_core';

test('1. Valid Ed25519 sign + verify with PKCS#8 passphrase encryption', () => {
  const passphrase = 'correct-horse-battery-staple';
  const kp = generateKeypair('Ed25519', passphrase);

  assert.equal(kp.algorithm, 'Ed25519');
  assert.equal(kp.encrypted, true);
  assert.ok(kp.private_pem.includes('BEGIN ENCRYPTED PRIVATE KEY'));
  assert.ok(kp.public_pem.includes('BEGIN PUBLIC KEY'));
  assert.equal(kp.fingerprint_sha256.split(':').length, 16);

  const payload = Buffer.from('Authorize wire transfer of $48,500.00 USD to IBAN DE89-3704-0044.', 'utf-8');
  const bundle = signBytes(kp.private_pem, payload, passphrase, 'text', 'invoice.txt');

  assert.equal(bundle.algorithm, 'Ed25519');
  assert.equal(bundle.public_key_fingerprint, kp.fingerprint_sha256);
  assert.equal(bundle.payload_sha256, computeSha256Hex(payload));

  const verification = verifyBytes(kp.public_pem, payload, bundle.signature_b64);
  assert.equal(verification.is_valid, true);
  assert.equal(verification.algorithm, 'Ed25519');
  assert.equal(verification.public_key_fingerprint, kp.fingerprint_sha256);
});

test('2. Valid RSA-2048 (PSS + SHA-256) sign + verify', () => {
  const kp = generateKeypair('RSA-2048', '');
  assert.equal(kp.algorithm, 'RSA-2048');
  assert.equal(kp.encrypted, false);
  assert.ok(kp.private_pem.includes('BEGIN PRIVATE KEY'));

  const payload = Buffer.from('RSA-2048 PSS with MGF1(SHA-256) max salt length verification test.', 'utf-8');
  const bundle = signBytes(kp.private_pem, payload, '');

  assert.equal(bundle.algorithm, 'RSA-2048');

  const result = verifyBytes(kp.public_pem, payload, bundle.signature_b64);
  assert.equal(result.is_valid, true);
  assert.equal(result.algorithm, 'RSA-2048');
});

test('3. Single-byte message tampering fails for both Ed25519 and RSA-2048', () => {
  const original = Buffer.from('Amount Due: $48,500.00 USD', 'utf-8');
  const tampered = Buffer.from('Amount Due: $98,500.00 USD', 'utf-8');

  for (const alg of ['Ed25519', 'RSA-2048'] as const) {
    const kp = generateKeypair(alg);
    const bundle = signBytes(kp.private_pem, original);
    const tamperedResult = verifyBytes(kp.public_pem, tampered, bundle.signature_b64);
    assert.equal(tamperedResult.is_valid, false, `Tampered payload must fail for ${alg}`);
    assert.ok(tamperedResult.reason.toLowerCase().includes('failed'));
  }
});

test('4. Wrong public key fails verification', () => {
  const alice = generateKeypair('Ed25519');
  const mallory = generateKeypair('Ed25519');
  const payload = Buffer.from('Signed exclusively by Alice.', 'utf-8');

  const bundle = signBytes(alice.private_pem, payload);
  const wrongKeyResult = verifyBytes(mallory.public_pem, payload, bundle.signature_b64);

  assert.equal(wrongKeyResult.is_valid, false);
  assert.equal(wrongKeyResult.public_key_fingerprint, mallory.fingerprint_sha256);
});

test('5. Corrupted signature and invalid Base64 fail gracefully without throwing', () => {
  const kp = generateKeypair('Ed25519');
  const payload = Buffer.from('Resilience against malformed inputs.', 'utf-8');
  const bundle = signBytes(kp.private_pem, payload);

  const badB64 = verifyBytes(kp.public_pem, payload, '!!!NOT_VALID_BASE64***');
  assert.equal(badB64.is_valid, false);
  assert.ok(badB64.reason.toLowerCase().includes('base64'));

  const flippedChar = (bundle.signature_b64.startsWith('A') ? 'B' : 'A') + bundle.signature_b64.slice(1);
  const corruptedSig = verifyBytes(kp.public_pem, payload, flippedChar);
  assert.equal(corruptedSig.is_valid, false);

  const badPem = verifyBytes('-----BEGIN PUBLIC KEY-----\nINVALID\n-----END PUBLIC KEY-----', payload, bundle.signature_b64);
  assert.equal(badPem.is_valid, false);
  assert.ok(badPem.reason.toLowerCase().includes('pem'));
});

test('6. Wrong passphrase throws an Error', () => {
  const kp = generateKeypair('Ed25519', 'my-secret-passphrase');
  const payload = Buffer.from('Confidential payload', 'utf-8');

  assert.throws(() => {
    signBytes(kp.private_pem, payload, 'wrong-passphrase');
  });

  assert.throws(() => {
    signBytes(kp.private_pem, payload, '');
  });
});

test('7. Binary file bytes sign + verify + single-bit flip failure', () => {
  const kp = generateKeypair('Ed25519');
  const binaryHeader = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0xff, 0xfe, 0xfd]);

  const bundle = signBytes(kp.private_pem, binaryHeader, '', 'file', 'firmware_v2.bin');
  assert.equal(bundle.payload_type, 'file');
  assert.equal(bundle.filename, 'firmware_v2.bin');

  const validRes = verifyBytes(kp.public_pem, binaryHeader, bundle.signature_b64);
  assert.equal(validRes.is_valid, true);

  const mutatedBinary = Buffer.from(binaryHeader);
  mutatedBinary[mutatedBinary.length - 1] ^= 0xff;
  const invalidRes = verifyBytes(kp.public_pem, mutatedBinary, bundle.signature_b64);
  assert.equal(invalidRes.is_valid, false);
});

test('8. SignatureBundle JSON serialization round-trip and missing-field validation', () => {
  const kp = generateKeypair('Ed25519');
  const bundle = signBytes(kp.private_pem, Buffer.from('Canonical JSON test', 'utf-8'), '', 'file', 'release.tar.gz');

  const jsonStr = bundle.toJson();
  const restored = SignatureBundle.fromJson(jsonStr);

  assert.equal(restored.algorithm, bundle.algorithm);
  assert.equal(restored.signature_b64, bundle.signature_b64);
  assert.equal(restored.payload_sha256, bundle.payload_sha256);
  assert.equal(restored.public_key_fingerprint, bundle.public_key_fingerprint);
  assert.equal(restored.filename, 'release.tar.gz');

  const keys = Object.keys(JSON.parse(jsonStr));
  assert.deepEqual(keys, [...keys].sort());

  const broken = JSON.parse(jsonStr);
  delete broken.signature_b64;
  assert.throws(() => {
    SignatureBundle.fromJson(JSON.stringify(broken));
  });
});

test('9. Public key fingerprint matches uppercase colon-separated 4-char hex format', () => {
  const kp = generateKeypair('Ed25519');
  const fp = publicKeyFingerprint(kp.public_pem);
  assert.match(fp, /^([0-9A-F]{4}:){15}[0-9A-F]{4}$/);
});
