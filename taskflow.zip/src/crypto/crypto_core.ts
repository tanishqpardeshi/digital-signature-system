/**
 * crypto_core.ts — Pure TypeScript Cryptographic Engine (Node.js `node:crypto`).
 *
 * Mirrors every requirement of `digital-signature-system/crypto_core.py`:
 * - Algorithms Supported:
 *   1. Ed25519 (recommended default): 32-byte keys, 64-byte deterministic detached signatures.
 *   2. RSA-2048: publicExponent=65537, modulusLength=2048, signed and verified using
 *      RSASSA-PSS padding (MGF1(SHA-256), saltLength=RSA_PSS_SALTLEN_MAX_SIGN) with SHA-256.
 * - Structured Interfaces / Classes:
 *   - KeyPair
 *   - SignatureBundle (with canonical toJson() sort_keys=True and fromJson() validation)
 *   - VerificationResult
 * - Core Functions:
 *   - generateKeypair(algorithm, passphrase)
 *   - publicKeyFingerprint(publicPem)
 *   - signBytes(privatePem, data, passphrase, payloadType, filename)
 *   - verifyBytes(publicPem, data, signatureB64)
 */

import crypto from 'node:crypto';

export type AlgorithmType = 'Ed25519' | 'RSA-2048';
export type PayloadType = 'text' | 'file';

export const SUPPORTED_ALGORITHMS: readonly AlgorithmType[] = ['Ed25519', 'RSA-2048'] as const;

export interface KeyPair {
  algorithm: AlgorithmType;
  private_pem: string;
  public_pem: string;
  fingerprint_sha256: string;
  encrypted: boolean;
  created_at: string;
}

export interface SignatureBundleData {
  algorithm: AlgorithmType;
  filename: string | null;
  payload_sha256: string;
  payload_type: PayloadType;
  public_key_fingerprint: string;
  signature_b64: string;
  signed_at: string;
}

export class SignatureBundle implements SignatureBundleData {
  public readonly algorithm: AlgorithmType;
  public readonly signature_b64: string;
  public readonly payload_sha256: string;
  public readonly public_key_fingerprint: string;
  public readonly signed_at: string;
  public readonly payload_type: PayloadType;
  public readonly filename: string | null;

  constructor(params: SignatureBundleData) {
    this.algorithm = params.algorithm;
    this.signature_b64 = params.signature_b64;
    this.payload_sha256 = params.payload_sha256;
    this.public_key_fingerprint = params.public_key_fingerprint;
    this.signed_at = params.signed_at;
    this.payload_type = params.payload_type;
    this.filename = params.filename ?? null;
  }

  /**
   * Serialize bundle to canonical JSON with alphabetically sorted keys (matching Python sort_keys=True).
   */
  public toJson(): string {
    const canonical: Record<string, string | null> = {
      algorithm: this.algorithm,
      filename: this.filename,
      payload_sha256: this.payload_sha256,
      payload_type: this.payload_type,
      public_key_fingerprint: this.public_key_fingerprint,
      signature_b64: this.signature_b64,
      signed_at: this.signed_at,
    };
    return JSON.stringify(canonical, null, 2);
  }

  /**
   * Deserialize and strictly validate a SignatureBundle from a JSON string.
   */
  public static fromJson(rawJson: string): SignatureBundle {
    if (typeof rawJson !== 'string' || !rawJson.trim()) {
      throw new Error('SignatureBundle JSON input cannot be empty.');
    }

    let parsed: unknown;
    try {
      parsed = JSON.parse(rawJson);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      throw new Error(`Malformed JSON in signature bundle: ${msg}`);
    }

    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      throw new Error('SignatureBundle JSON root must be an object.');
    }

    const record = parsed as Record<string, unknown>;
    const requiredFields = [
      'algorithm',
      'signature_b64',
      'payload_sha256',
      'public_key_fingerprint',
      'signed_at',
      'payload_type',
    ] as const;

    const missing = requiredFields.filter(
      (field) => !(field in record) || record[field] === null || record[field] === undefined || record[field] === ''
    );
    if (missing.length > 0) {
      throw new Error(`Missing required field(s) in SignatureBundle: ${missing.join(', ')}`);
    }

    const algorithm = record.algorithm;
    if (algorithm !== 'Ed25519' && algorithm !== 'RSA-2048') {
      throw new Error(`Unsupported algorithm in SignatureBundle: ${String(algorithm)}`);
    }

    const payloadType = record.payload_type;
    if (payloadType !== 'text' && payloadType !== 'file') {
      throw new Error(`Invalid payload_type in SignatureBundle: ${String(payloadType)}`);
    }

    const filename = record.filename ?? null;
    if (filename !== null && typeof filename !== 'string') {
      throw new Error("Field 'filename' must be a string or null.");
    }

    return new SignatureBundle({
      algorithm,
      signature_b64: String(record.signature_b64),
      payload_sha256: String(record.payload_sha256),
      public_key_fingerprint: String(record.public_key_fingerprint),
      signed_at: String(record.signed_at),
      payload_type: payloadType,
      filename,
    });
  }
}

export interface VerificationResult {
  is_valid: boolean;
  algorithm: string;
  payload_sha256: string;
  public_key_fingerprint: string;
  reason: string;
}

export function utcNowIso(): string {
  return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
}

export function computeSha256Hex(data: Buffer | Uint8Array): string {
  return crypto.createHash('sha256').update(data).digest('hex');
}

export function formatColonHexGroups(hexDigest: string, groupSize = 4): string {
  const upper = hexDigest.toUpperCase();
  const groups: string[] = [];
  for (let i = 0; i < upper.length; i += groupSize) {
    groups.push(upper.slice(i, i + groupSize));
  }
  return groups.join(':');
}

/**
 * Compute SHA-256 over the DER-encoded SubjectPublicKeyInfo of `publicPem`
 * and format as uppercase colon-separated 4-character hex groups.
 */
export function publicKeyFingerprint(publicPem: string): string {
  if (typeof publicPem !== 'string' || !publicPem.trim()) {
    throw new Error('Public key PEM cannot be empty.');
  }

  let pubKeyObj: crypto.KeyObject;
  try {
    pubKeyObj = crypto.createPublicKey(publicPem);
  } catch {
    throw new Error('Invalid or unsupported public key PEM format.');
  }

  const derBytes = pubKeyObj.export({
    type: 'spki',
    format: 'der',
  });
  const digestHex = crypto.createHash('sha256').update(derBytes).digest('hex');
  return formatColonHexGroups(digestHex, 4);
}

/**
 * Generate an Ed25519 or RSA-2048 key pair in memory.
 * Private key is serialized as PKCS#8 PEM (encrypted with AES-256-CBC if passphrase is provided).
 * Public key is serialized as SubjectPublicKeyInfo (spki) PEM.
 */
export function generateKeypair(algorithm: AlgorithmType = 'Ed25519', passphrase = ''): KeyPair {
  if (algorithm !== 'Ed25519' && algorithm !== 'RSA-2048') {
    throw new Error(`Unsupported algorithm '${String(algorithm)}'. Choose 'Ed25519' or 'RSA-2048'.`);
  }

  const isEncrypted = Boolean(passphrase && passphrase.length > 0);

  let privatePem: string;
  let publicPem: string;

  if (algorithm === 'Ed25519') {
    const pair = crypto.generateKeyPairSync('ed25519');
    privatePem = pair.privateKey
      .export(
        isEncrypted
          ? {
              type: 'pkcs8',
              format: 'pem',
              cipher: 'aes-256-cbc',
              passphrase,
            }
          : {
              type: 'pkcs8',
              format: 'pem',
            }
      )
      .toString();
    publicPem = pair.publicKey
      .export({
        type: 'spki',
        format: 'pem',
      })
      .toString();
  } else {
    const pair = crypto.generateKeyPairSync('rsa', {
      modulusLength: 2048,
      publicExponent: 65537,
    });
    privatePem = pair.privateKey
      .export(
        isEncrypted
          ? {
              type: 'pkcs8',
              format: 'pem',
              cipher: 'aes-256-cbc',
              passphrase,
            }
          : {
              type: 'pkcs8',
              format: 'pem',
            }
      )
      .toString();
    publicPem = pair.publicKey
      .export({
        type: 'spki',
        format: 'pem',
      })
      .toString();
  }

  return {
    algorithm,
    private_pem: privatePem,
    public_pem: publicPem,
    fingerprint_sha256: publicKeyFingerprint(publicPem),
    encrypted: isEncrypted,
    created_at: utcNowIso(),
  };
}

/**
 * Sign raw `data` bytes using an Ed25519 or RSA-2048 private key in PEM format.
 * Auto-detects whether the loaded private key is Ed25519 or RSA.
 */
export function signBytes(
  privatePem: string,
  data: Buffer | Uint8Array,
  passphrase = '',
  payloadType: PayloadType = 'text',
  filename: string | null = null
): SignatureBundle {
  if (typeof privatePem !== 'string' || !privatePem.trim()) {
    throw new Error('Private key PEM cannot be empty.');
  }
  if (!(data instanceof Uint8Array)) {
    throw new Error('Payload data must be raw bytes.');
  }
  if (payloadType !== 'text' && payloadType !== 'file') {
    throw new Error("payloadType must be either 'text' or 'file'.");
  }

  const isEncryptedPem = privatePem.includes('ENCRYPTED PRIVATE KEY');
  if (!isEncryptedPem && passphrase) {
    throw new Error('Passphrase was provided for an unencrypted private key.');
  }
  if (isEncryptedPem && !passphrase) {
    throw new Error('Private key is encrypted; a passphrase is required.');
  }

  let privateKey: crypto.KeyObject;
  try {
    privateKey = crypto.createPrivateKey(
      passphrase
        ? {
            key: privatePem,
            format: 'pem',
            passphrase,
          }
        : {
            key: privatePem,
            format: 'pem',
          }
    );
  } catch {
    throw new Error('Failed to load private key PEM. Ensure the PEM is valid and the passphrase is correct.');
  }

  const rawBuffer = Buffer.from(data);
  const keyType = privateKey.asymmetricKeyType;

  let algorithm: AlgorithmType;
  let signatureBuffer: Buffer;

  if (keyType === 'ed25519') {
    algorithm = 'Ed25519';
    signatureBuffer = crypto.sign(null, rawBuffer, privateKey);
  } else if (keyType === 'rsa' || keyType === 'rsa-pss') {
    algorithm = 'RSA-2048';
    signatureBuffer = crypto.sign('sha256', rawBuffer, {
      key: privateKey,
      padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
      saltLength: crypto.constants.RSA_PSS_SALTLEN_MAX_SIGN,
    });
  } else {
    throw new Error(`Unsupported private key algorithm: ${String(keyType)}. Only Ed25519 and RSA are supported.`);
  }

  const derivedPublicPem = crypto
    .createPublicKey(privateKey)
    .export({
      type: 'spki',
      format: 'pem',
    })
    .toString();

  return new SignatureBundle({
    algorithm,
    signature_b64: signatureBuffer.toString('base64'),
    payload_sha256: computeSha256Hex(rawBuffer),
    public_key_fingerprint: publicKeyFingerprint(derivedPublicPem),
    signed_at: utcNowIso(),
    payload_type: payloadType,
    filename,
  });
}

const STRICT_BASE64_REGEX = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;

/**
 * Verify a Base64-encoded detached signature against `publicPem` and `data` bytes.
 * Auto-detects key type and catches malformed Base64, invalid PEM, or signature mismatch cleanly.
 */
export function verifyBytes(
  publicPem: string,
  data: Buffer | Uint8Array,
  signatureB64: string
): VerificationResult {
  const rawBuffer = data instanceof Uint8Array ? Buffer.from(data) : Buffer.alloc(0);
  const payloadHash = computeSha256Hex(rawBuffer);

  if (typeof publicPem !== 'string' || !publicPem.trim()) {
    return {
      is_valid: false,
      algorithm: 'Unknown',
      payload_sha256: payloadHash,
      public_key_fingerprint: 'N/A',
      reason: 'Public key PEM is empty.',
    };
  }

  if (typeof signatureB64 !== 'string' || !signatureB64.trim()) {
    return {
      is_valid: false,
      algorithm: 'Unknown',
      payload_sha256: payloadHash,
      public_key_fingerprint: 'N/A',
      reason: 'Signature Base64 input is empty.',
    };
  }

  let publicKey: crypto.KeyObject;
  let fingerprint: string;
  try {
    publicKey = crypto.createPublicKey(publicPem);
    const derBytes = publicKey.export({ type: 'spki', format: 'der' });
    fingerprint = formatColonHexGroups(crypto.createHash('sha256').update(derBytes).digest('hex'), 4);
  } catch {
    return {
      is_valid: false,
      algorithm: 'Unknown',
      payload_sha256: payloadHash,
      public_key_fingerprint: 'N/A',
      reason: 'Invalid or corrupted Public Key PEM format.',
    };
  }

  const keyType = publicKey.asymmetricKeyType;
  let algorithm: AlgorithmType;
  if (keyType === 'ed25519') {
    algorithm = 'Ed25519';
  } else if (keyType === 'rsa' || keyType === 'rsa-pss') {
    algorithm = 'RSA-2048';
  } else {
    return {
      is_valid: false,
      algorithm: String(keyType ?? 'Unknown'),
      payload_sha256: payloadHash,
      public_key_fingerprint: fingerprint,
      reason: `Unsupported public key type: ${String(keyType)}.`,
    };
  }

  const cleanedB64 = signatureB64.trim().replace(/\s+/g, '');
  if (!cleanedB64 || cleanedB64.length % 4 !== 0 || !STRICT_BASE64_REGEX.test(cleanedB64)) {
    return {
      is_valid: false,
      algorithm,
      payload_sha256: payloadHash,
      public_key_fingerprint: fingerprint,
      reason: 'Malformed Base64 encoding in signature.',
    };
  }

  const signatureBuffer = Buffer.from(cleanedB64, 'base64');
  if (signatureBuffer.length === 0) {
    return {
      is_valid: false,
      algorithm,
      payload_sha256: payloadHash,
      public_key_fingerprint: fingerprint,
      reason: 'Decoded signature is empty.',
    };
  }

  try {
    let isValid = false;
    if (algorithm === 'Ed25519') {
      isValid = crypto.verify(null, rawBuffer, publicKey, signatureBuffer);
    } else {
      isValid = crypto.verify(
        'sha256',
        rawBuffer,
        {
          key: publicKey,
          padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
          saltLength: crypto.constants.RSA_PSS_SALTLEN_AUTO,
        },
        signatureBuffer
      );
    }

    if (!isValid) {
      return {
        is_valid: false,
        algorithm,
        payload_sha256: payloadHash,
        public_key_fingerprint: fingerprint,
        reason:
          'Cryptographic verification failed: payload was modified, signature was corrupted, or public key does not match the signer.',
      };
    }

    return {
      is_valid: true,
      algorithm,
      payload_sha256: payloadHash,
      public_key_fingerprint: fingerprint,
      reason: 'Cryptographic signature verified: authenticity and payload integrity confirmed.',
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return {
      is_valid: false,
      algorithm,
      payload_sha256: payloadHash,
      public_key_fingerprint: fingerprint,
      reason: `Verification error: ${msg}`,
    };
  }
}
