import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Zap,
  Key,
  Lock,
  Unlock,
  Activity,
} from 'lucide-react';
import {
  ActiveTabId,
  ActivityLogEntry,
  AlgorithmType,
  KeyPair,
  PayloadType,
  ProjectSourceFile,
  SAMPLE_INVOICE_TEXT,
  SignatureBundleData,
  VerificationResult,
} from './types';
import { KeyManagementTab } from './components/KeyManagementTab';
import { SignTab } from './components/SignTab';
import { VerifyTab } from './components/VerifyTab';
import { ArchitectureTab } from './components/ArchitectureTab';
import { StreamlitBundleTab } from './components/StreamlitBundleTab';

function formatUtcTimestamp(): string {
  return new Date().toISOString().replace('T', ' ').replace(/\.\d{3}Z$/, ' UTC');
}

function mutateTextForTamperSimulation(currentText: string): string {
  if (!currentText) return 'TAMPERED_PAYLOAD_1';
  if (currentText.includes('$48,500.00')) {
    return currentText.replace('$48,500.00', '$98,500.00');
  }
  if (currentText.includes('$98,500.00')) {
    return currentText.replace('$98,500.00', '$48,500.00');
  }
  const lastChar = currentText[currentText.length - 1];
  const replacement = lastChar !== 'X' ? 'X' : 'Y';
  return currentText.slice(0, -1) + replacement;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTabId>('keys');
  const [activeKeypair, setActiveKeypair] = useState<KeyPair | null>(null);
  const [activePassphrase, setActivePassphrase] = useState<string>('');
  const [signText, setSignText] = useState<string>(SAMPLE_INVOICE_TEXT);
  const [lastBundle, setLastBundle] = useState<SignatureBundleData | null>(null);
  const [lastBundleJson, setLastBundleJson] = useState<string>('');
  const [verifyText, setVerifyText] = useState<string>(SAMPLE_INVOICE_TEXT);
  const [verifySignatureB64, setVerifySignatureB64] = useState<string>('');
  const [verifyResult, setVerifyResult] = useState<VerificationResult | null>(null);
  const [activityLog, setActivityLog] = useState<ActivityLogEntry[]>([]);
  const [projectFiles, setProjectFiles] = useState<ProjectSourceFile[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const appendActivityLog = (entries: Omit<ActivityLogEntry, 'id' | 'time_utc'>[]) => {
    const nowStr = formatUtcTimestamp();
    const formatted: ActivityLogEntry[] = entries.map((item, idx) => ({
      id: `${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 6)}`,
      time_utc: nowStr,
      action: item.action,
      algorithm: item.algorithm,
      key_fingerprint:
        item.key_fingerprint.length > 24
          ? `${item.key_fingerprint.slice(0, 24)}...`
          : item.key_fingerprint,
      status: item.status,
    }));
    setActivityLog((prev) => [...formatted, ...prev].slice(0, 20));
  };

  useEffect(() => {
    fetch('/api/project-files')
      .then((res) => res.json())
      .then((data) => {
        if (data?.ok && Array.isArray(data.files)) {
          setProjectFiles(data.files);
        }
      })
      .catch(() => {
        // Ignore initial fetch errors
      });
  }, []);

  const handleQuickStartDemo = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/crypto/quick-start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await response.json();
      if (data?.ok) {
        const kp: KeyPair = data.keypair;
        const bundle: SignatureBundleData = data.bundle;
        const verification: VerificationResult = data.verification;

        setActiveKeypair(kp);
        setActivePassphrase('');
        setSignText(data.sample_text);
        setLastBundle(bundle);
        setLastBundleJson(data.bundle_json);
        setVerifyText(data.sample_text);
        setVerifySignatureB64(bundle.signature_b64);
        setVerifyResult(verification);
        setActiveTab('verify');

        appendActivityLog([
          {
            action: 'Quick-Start Verify',
            algorithm: verification.algorithm,
            key_fingerprint: verification.public_key_fingerprint,
            status: verification.is_valid ? 'VALID' : 'INVALID',
          },
          {
            action: 'Quick-Start Sign',
            algorithm: bundle.algorithm,
            key_fingerprint: bundle.public_key_fingerprint,
            status: 'SIGNED',
          },
          {
            action: 'Quick-Start KeyGen',
            algorithm: kp.algorithm,
            key_fingerprint: kp.fingerprint_sha256,
            status: 'GENERATED',
          },
        ]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateKeypair = async (algorithm: AlgorithmType, passphrase: string) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/crypto/generate-keypair', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ algorithm, passphrase }),
      });
      const data = await response.json();
      if (!data?.ok) {
        throw new Error(data?.error || 'Failed to generate key pair.');
      }
      const kp: KeyPair = data.keypair;
      setActiveKeypair(kp);
      setActivePassphrase(passphrase);
      appendActivityLog([
        {
          action: 'Generate KeyPair',
          algorithm: kp.algorithm,
          key_fingerprint: kp.fingerprint_sha256,
          status: kp.encrypted ? 'ENCRYPTED' : 'UNENCRYPTED',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignPayload = async (params: {
    private_pem: string;
    passphrase: string;
    payload_type: PayloadType;
    text?: string;
    data_b64?: string;
    filename: string | null;
  }) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/crypto/sign', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await response.json();
      if (!data?.ok) {
        appendActivityLog([
          {
            action: 'Sign Error',
            algorithm: 'Unknown',
            key_fingerprint: 'N/A',
            status: 'FAILED',
          },
        ]);
        throw new Error(data?.error || 'Signing failed.');
      }

      const bundle: SignatureBundleData = data.bundle;
      setLastBundle(bundle);
      setLastBundleJson(data.bundle_json);
      if (params.payload_type === 'text' && typeof params.text === 'string') {
        setVerifyText(params.text);
      }
      setVerifySignatureB64(bundle.signature_b64);

      appendActivityLog([
        {
          action: `Sign (${bundle.payload_type})`,
          algorithm: bundle.algorithm,
          key_fingerprint: bundle.public_key_fingerprint,
          status: 'SIGNED',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyPayload = async (params: {
    public_pem: string;
    text?: string;
    data_b64?: string;
    signature_b64?: string;
    bundle_json?: string;
  }) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/crypto/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });
      const data = await response.json();
      if (data?.ok && data.result) {
        const result: VerificationResult = data.result;
        setVerifyResult(result);
        appendActivityLog([
          {
            action: 'Verify Signature',
            algorithm: result.algorithm,
            key_fingerprint: result.public_key_fingerprint,
            status: result.is_valid ? 'VALID' : 'INVALID',
          },
        ]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSimulateTampering = async () => {
    const mutated = mutateTextForTamperSimulation(verifyText);
    setVerifyText(mutated);

    if (activeKeypair?.public_pem && verifySignatureB64.trim()) {
      setIsLoading(true);
      try {
        const response = await fetch('/api/crypto/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            public_pem: activeKeypair.public_pem,
            text: mutated,
            signature_b64: verifySignatureB64,
          }),
        });
        const data = await response.json();
        if (data?.ok && data.result) {
          const result: VerificationResult = data.result;
          setVerifyResult(result);
          appendActivityLog([
            {
              action: 'Tamper Simulation',
              algorithm: result.algorithm,
              key_fingerprint: result.public_key_fingerprint,
              status: result.is_valid ? 'VALID' : 'TAMPERED',
            },
          ]);
        }
      } finally {
        setIsLoading(false);
      }
    }
  };

  const navItems: { id: ActiveTabId; label: string }[] = [
    { id: 'keys', label: 'Key Management' },
    { id: 'sign', label: 'Sign Message / File' },
    { id: 'verify', label: 'Verify & Tamper Test' },
    { id: 'architecture', label: 'How It Works' },
    { id: 'streamlit-code', label: 'Streamlit Bundle' },
  ];

  return (
    <div className="min-h-screen bg-[#0B0F19] text-slate-100 flex flex-col">
      {/* 3-Zone Top Bar Contract */}
      <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-slate-950 border-b border-slate-800/90 sticky top-0 z-30">
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('keys');
          }}
          className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0"
        >
          Digital Signature Verification System
        </a>

        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-300" aria-label="Primary Workspace Navigation">
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`py-1 transition-colors cursor-pointer whitespace-nowrap shrink-0 border-b-2 ${
                activeTab === item.id
                  ? 'text-white border-blue-500 font-semibold'
                  : 'text-slate-400 border-transparent hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={handleQuickStartDemo}
            disabled={isLoading}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>1-Click Quick-Start Demo</span>
          </button>
        </div>
      </header>

      {/* Main Layout: Sidebar + Content Viewport */}
      <div className="flex-1 flex flex-col lg:flex-row">
        {/* Sidebar: Quick-Start Demo, Active Session Key Card, and In-Memory Session Activity Log */}
        <aside className="w-full lg:w-80 xl:w-88 bg-slate-950/70 border-b lg:border-b-0 lg:border-r border-slate-800/90 p-5 space-y-6 shrink-0">
          <div className="space-y-2.5">
            <div className="text-xs font-semibold text-slate-300">Instant Evaluator Demo</div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Generate an ephemeral Ed25519 key pair in memory, sign a sample invoice, and pre-populate the Verify &amp; Tamper Test tab in one click.
            </p>
            <button
              type="button"
              onClick={handleQuickStartDemo}
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <Zap className="w-4 h-4" />
              <span>Run 1-Click Quick-Start Demo</span>
            </button>
          </div>

          <div className="border-t border-slate-800/90 pt-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-blue-400" />
                <span>Active Session Key Card</span>
              </span>
            </div>

            {!activeKeypair ? (
              <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3.5 text-xs text-slate-400 leading-relaxed">
                No active session key loaded. Generate a key pair in Tab 1 or click the Quick-Start Demo button above.
              </div>
            ) : (
              <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-3.5 space-y-2.5 text-xs">
                <div className="flex items-center justify-between text-slate-300">
                  <span>Algorithm</span>
                  <span className="font-mono font-semibold text-white">{activeKeypair.algorithm}</span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span>Encryption Status</span>
                  <span className="inline-flex items-center gap-1 font-medium text-slate-200">
                    {activeKeypair.encrypted ? (
                      <>
                        <Lock className="w-3 h-3 text-amber-400" />
                        <span>Encrypted (PKCS#8)</span>
                      </>
                    ) : (
                      <>
                        <Unlock className="w-3 h-3 text-emerald-400" />
                        <span>Unencrypted</span>
                      </>
                    )}
                  </span>
                </div>
                <div>
                  <div className="text-slate-400 mb-1">SHA-256 Fingerprint</div>
                  <pre className="bg-slate-950 border border-slate-800 rounded p-2 text-[11px] font-mono text-emerald-400 break-all whitespace-pre-wrap select-all">
                    {activeKeypair.fingerprint_sha256}
                  </pre>
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-slate-800/90 pt-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                <span>In-Memory Session Activity Log</span>
              </span>
              <span className="text-[11px] font-mono text-slate-400 tabular-nums">
                {activityLog.length}/20
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Last 20 operations. Zero private keys, passphrases, or raw payloads logged.
            </p>

            {activityLog.length === 0 ? (
              <div className="bg-slate-900/60 border border-slate-800 rounded-lg p-3 text-xs text-slate-400">
                No operations recorded in this session yet.
              </div>
            ) : (
              <div className="bg-slate-900/90 border border-slate-800 rounded-lg overflow-hidden">
                <div className="overflow-x-auto max-h-72">
                  <table className="w-full text-left border-collapse text-[11px]">
                    <thead>
                      <tr className="border-b border-slate-800 bg-slate-950 text-slate-400">
                        <th className="py-2 px-2 font-medium">Time UTC / Action</th>
                        <th className="py-2 px-1.5 font-medium">Alg</th>
                        <th className="py-2 px-2 font-medium text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/70 font-mono">
                      {activityLog.map((entry) => (
                        <tr key={entry.id} className="hover:bg-slate-800/40">
                          <td className="py-2 px-2 text-slate-200">
                            <div className="font-sans font-medium text-xs text-slate-100">{entry.action}</div>
                            <div className="text-[10px] text-slate-400 tabular-nums">{entry.time_utc}</div>
                            <div className="text-[10px] text-emerald-400/80 truncate max-w-[140px]" title={entry.key_fingerprint}>
                              {entry.key_fingerprint}
                            </div>
                          </td>
                          <td className="py-2 px-1.5 text-slate-300">{entry.algorithm}</td>
                          <td className="py-2 px-2 text-right">
                            <span
                              className={
                                entry.status === 'VALID' || entry.status === 'SIGNED' || entry.status === 'GENERATED'
                                  ? 'text-emerald-400 font-semibold'
                                  : entry.status === 'ENCRYPTED' || entry.status === 'UNENCRYPTED'
                                  ? 'text-blue-400 font-semibold'
                                  : 'text-red-400 font-semibold'
                              }
                            >
                              {entry.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </aside>

        {/* Main Workspace Content */}
        <main className="flex-1 p-6 lg:p-8 max-w-6xl w-full mx-auto space-y-6">
          {/* Mandatory Prominent Security Disclaimer Warning Banner */}
          <div
            role="note"
            className="bg-amber-950/60 border border-amber-700/70 rounded-xl p-4 flex items-start gap-3.5"
          >
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-100/95 leading-relaxed">
              <strong className="font-semibold text-amber-300">Educational Demo:</strong> All cryptographic operations run strictly in memory and no keys are stored on disk. In production systems, signing must happen locally on the client device—do not upload real production private keys here.
            </p>
          </div>

          {/* Interactive Workspace Tab Bar */}
          <div
            role="tablist"
            aria-label="Cryptographic Workspace Tabs"
            className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900 border border-slate-800 rounded-xl"
          >
            <button
              role="tab"
              aria-selected={activeTab === 'keys'}
              type="button"
              onClick={() => setActiveTab('keys')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                activeTab === 'keys'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
              }`}
            >
              1. Key Management
            </button>
            <button
              role="tab"
              aria-selected={activeTab === 'sign'}
              type="button"
              onClick={() => setActiveTab('sign')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                activeTab === 'sign'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
              }`}
            >
              2. Sign Message / File
            </button>
            <button
              role="tab"
              aria-selected={activeTab === 'verify'}
              type="button"
              onClick={() => setActiveTab('verify')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                activeTab === 'verify'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
              }`}
            >
              3. Verify &amp; Tamper Test
            </button>
            <button
              role="tab"
              aria-selected={activeTab === 'architecture'}
              type="button"
              onClick={() => setActiveTab('architecture')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                activeTab === 'architecture'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
              }`}
            >
              4. How It Works &amp; Architecture
            </button>
            <button
              role="tab"
              aria-selected={activeTab === 'streamlit-code'}
              type="button"
              onClick={() => setActiveTab('streamlit-code')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                activeTab === 'streamlit-code'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
              }`}
            >
              5. Python &amp; Streamlit Source Files
            </button>
          </div>

          {/* Active Tab Panel */}
          <div className="pt-1">
            {activeTab === 'keys' && (
              <KeyManagementTab
                activeKeypair={activeKeypair}
                onGenerateKeypair={handleGenerateKeypair}
                isLoading={isLoading}
              />
            )}
            {activeTab === 'sign' && (
              <SignTab
                activeKeypair={activeKeypair}
                activePassphrase={activePassphrase}
                signText={signText}
                onChangeSignText={setSignText}
                lastBundle={lastBundle}
                lastBundleJson={lastBundleJson}
                onSignPayload={handleSignPayload}
                isLoading={isLoading}
              />
            )}
            {activeTab === 'verify' && (
              <VerifyTab
                activeKeypair={activeKeypair}
                verifyText={verifyText}
                onChangeVerifyText={setVerifyText}
                verifySignatureB64={verifySignatureB64}
                onChangeVerifySignatureB64={setVerifySignatureB64}
                verifyResult={verifyResult}
                onVerifyPayload={handleVerifyPayload}
                onSimulateTampering={handleSimulateTampering}
                isLoading={isLoading}
              />
            )}
            {activeTab === 'architecture' && <ArchitectureTab />}
            {activeTab === 'streamlit-code' && <StreamlitBundleTab files={projectFiles} />}
          </div>
        </main>
      </div>
    </div>
  );
}
