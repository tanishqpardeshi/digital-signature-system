import React, { useState } from 'react';
import { Download, Key, Lock, Unlock, ChevronDown, ChevronUp, Copy, Check } from 'lucide-react';
import { AlgorithmType, KeyPair } from '../types';

interface KeyManagementTabProps {
  activeKeypair: KeyPair | null;
  onGenerateKeypair: (algorithm: AlgorithmType, passphrase: string) => Promise<void>;
  isLoading: boolean;
}

export const KeyManagementTab: React.FC<KeyManagementTabProps> = ({
  activeKeypair,
  onGenerateKeypair,
  isLoading,
}) => {
  const [algorithm, setAlgorithm] = useState<AlgorithmType>('Ed25519');
  const [passphrase, setPassphrase] = useState<string>('');
  const [previewExpanded, setPreviewExpanded] = useState<boolean>(true);
  const [copiedFp, setCopiedFp] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onGenerateKeypair(algorithm, passphrase);
  };

  const handleDownloadPem = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'application/x-pem-file;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleCopyFingerprint = () => {
    if (!activeKeypair) return;
    navigator.clipboard.writeText(activeKeypair.fingerprint_sha256);
    setCopiedFp(true);
    setTimeout(() => setCopiedFp(false), 1800);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-100">Asymmetric Key Pair Generation</h2>
        <p className="text-sm text-slate-400 mt-1">
          Generate standards-compliant Ed25519 (RFC 8032) or RSA-2048 (PKCS#8 / SubjectPublicKeyInfo) keys strictly in volatile memory.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-5"
        >
          <div>
            <label htmlFor="algorithm-select" className="block text-sm font-medium text-slate-200 mb-2">
              Select Signature Algorithm
            </label>
            <select
              id="algorithm-select"
              value={algorithm}
              onChange={(e) => setAlgorithm(e.target.value as AlgorithmType)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-blue-500"
            >
              <option value="Ed25519">Ed25519 — Recommended Default (RFC 8032)</option>
              <option value="RSA-2048">RSA-2048 — RSASSA-PSS + SHA-256</option>
            </select>
            <p className="text-xs text-slate-400 mt-1.5">
              {algorithm === 'Ed25519'
                ? 'Fast constant-time Edwards-curve signatures (32B keys, 64B deterministic signatures).'
                : '2048-bit RSA modulus (e = 65537) using probabilistic PSS padding with MGF1(SHA-256).'}
            </p>
          </div>

          <div>
            <label htmlFor="key-passphrase-input" className="block text-sm font-medium text-slate-200 mb-2">
              Optional Private Key Passphrase (PKCS#8 Encryption)
            </label>
            <input
              id="key-passphrase-input"
              type="password"
              value={passphrase}
              onChange={(e) => setPassphrase(e.target.value)}
              placeholder="Leave empty for unencrypted PEM..."
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <p className="text-xs text-slate-400 mt-1.5">
              When set, encrypts the serialized PKCS#8 private key PEM with AES-256-CBC / BestAvailableEncryption.
            </p>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <Key className="w-4 h-4" />
            <span>{isLoading ? 'Generating Key Pair...' : 'Generate New Key Pair'}</span>
          </button>
        </form>

        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-5">
          {!activeKeypair ? (
            <div className="py-12 text-center space-y-3">
              <Key className="w-8 h-8 text-slate-500 mx-auto" />
              <div className="text-sm font-medium text-slate-300">No Active Session Key Pair</div>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Generate a key pair on the left or trigger the 1-Click Quick-Start Demo in the sidebar to inspect SHA-256 DER fingerprints and download PEM files.
              </p>
            </div>
          ) : (
            <>
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <div className="text-xs text-slate-400">Active Key Pair Metadata</div>
                  <div className="text-sm text-slate-200 mt-1 flex items-center gap-2">
                    <span className="font-semibold text-white">{activeKeypair.algorithm}</span>
                    <span aria-hidden="true">·</span>
                    <span className="inline-flex items-center gap-1 text-slate-300">
                      {activeKeypair.encrypted ? (
                        <>
                          <Lock className="w-3.5 h-3.5 text-amber-400" />
                          <span>Encrypted PKCS#8</span>
                        </>
                      ) : (
                        <>
                          <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Unencrypted PKCS#8</span>
                        </>
                      )}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-xs text-slate-400 tabular-nums">{activeKeypair.created_at}</span>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-medium text-slate-300">
                    Public Key SHA-256 Fingerprint (DER SubjectPublicKeyInfo)
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyFingerprint}
                    className="inline-flex items-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 cursor-pointer whitespace-nowrap"
                  >
                    {copiedFp ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedFp ? 'Copied' : 'Copy Fingerprint'}</span>
                  </button>
                </div>
                <pre className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-emerald-400 break-all whitespace-pre-wrap select-all">
                  {activeKeypair.fingerprint_sha256}
                </pre>
              </div>

              <div className="border border-slate-800 rounded-lg overflow-hidden">
                <button
                  type="button"
                  onClick={() => setPreviewExpanded(!previewExpanded)}
                  aria-expanded={previewExpanded}
                  className="w-full flex items-center justify-between px-4 py-2.5 bg-slate-950/70 hover:bg-slate-950 text-xs font-medium text-slate-200 transition-colors cursor-pointer"
                >
                  <span>Public Key PEM Preview (SubjectPublicKeyInfo)</span>
                  {previewExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
                {previewExpanded && (
                  <pre className="p-3.5 bg-slate-950 text-xs font-mono text-slate-300 overflow-x-auto leading-relaxed">
                    {activeKeypair.public_pem.trim()}
                  </pre>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => handleDownloadPem(activeKeypair.private_pem, 'private_key.pem')}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-100 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Download className="w-4 h-4 text-blue-400" />
                  <span>Download private_key.pem</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDownloadPem(activeKeypair.public_pem, 'public_key.pem')}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-100 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Download className="w-4 h-4 text-emerald-400" />
                  <span>Download public_key.pem</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
