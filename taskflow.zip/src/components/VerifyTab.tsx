import React, { useState } from 'react';
import { ShieldCheck, ShieldAlert, FlaskConical, Upload, FileText } from 'lucide-react';
import { KeyPair, PayloadType, VerificationResult } from '../types';

interface VerifyTabProps {
  activeKeypair: KeyPair | null;
  verifyText: string;
  onChangeVerifyText: (val: string) => void;
  verifySignatureB64: string;
  onChangeVerifySignatureB64: (val: string) => void;
  verifyResult: VerificationResult | null;
  onVerifyPayload: (params: {
    public_pem: string;
    text?: string;
    data_b64?: string;
    signature_b64?: string;
    bundle_json?: string;
  }) => Promise<void>;
  onSimulateTampering: () => Promise<void>;
  isLoading: boolean;
}

export const VerifyTab: React.FC<VerifyTabProps> = ({
  activeKeypair,
  verifyText,
  onChangeVerifyText,
  verifySignatureB64,
  onChangeVerifySignatureB64,
  verifyResult,
  onVerifyPayload,
  onSimulateTampering,
  isLoading,
}) => {
  const [pubSource, setPubSource] = useState<'session' | 'upload'>('session');
  const [uploadedPublicPem, setUploadedPublicPem] = useState<string>('');
  const [uploadedPubKeyName, setUploadedPubKeyName] = useState<string>('');
  const [payloadMode, setPayloadMode] = useState<PayloadType>('text');
  const [uploadedVerifyFileB64, setUploadedVerifyFileB64] = useState<string>('');
  const [uploadedVerifyFileName, setUploadedVerifyFileName] = useState<string>('');
  const [sigSource, setSigSource] = useState<'b64' | 'bundle'>('b64');
  const [uploadedBundleJson, setUploadedBundleJson] = useState<string>('');
  const [uploadedBundleName, setUploadedBundleName] = useState<string>('');

  const handlePublicKeyUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadedPubKeyName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedPublicPem(typeof reader.result === 'string' ? reader.result : '');
    };
    reader.readAsText(file);
  };

  const handleVerifyFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadedVerifyFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      const arrayBuffer = reader.result as ArrayBuffer;
      const bytes = new Uint8Array(arrayBuffer);
      let binary = '';
      for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      setUploadedVerifyFileB64(btoa(binary));
    };
    reader.readAsArrayBuffer(file);
  };

  const handleBundleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadedBundleName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      const content = typeof reader.result === 'string' ? reader.result : '';
      setUploadedBundleJson(content);
      try {
        const parsed = JSON.parse(content);
        if (typeof parsed.signature_b64 === 'string') {
          onChangeVerifySignatureB64(parsed.signature_b64);
        }
      } catch {
        // Handled cleanly by server validation
      }
    };
    reader.readAsText(file);
  };

  const handleVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const publicPem = pubSource === 'session' ? activeKeypair?.public_pem || '' : uploadedPublicPem;

    await onVerifyPayload({
      public_pem: publicPem,
      text: payloadMode === 'text' ? verifyText : undefined,
      data_b64: payloadMode === 'file' ? uploadedVerifyFileB64 : undefined,
      signature_b64: sigSource === 'b64' ? verifySignatureB64 : undefined,
      bundle_json: sigSource === 'bundle' ? uploadedBundleJson : undefined,
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-100">Verify Signature &amp; Interactive Tamper Laboratory</h2>
        <p className="text-sm text-slate-400 mt-1">
          Verify payload authenticity and integrity against a public key. Use Simulate Tampering on text mode to mutate one character and watch verification flip from Valid to Invalid.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleVerifySubmit}
          className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-5"
        >
          <div>
            <span className="block text-sm font-medium text-slate-200 mb-2">Public Key Source</span>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 border border-slate-800 rounded-lg">
              <button
                type="button"
                onClick={() => setPubSource('session')}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  pubSource === 'session'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Use Active Session Public Key
              </button>
              <button
                type="button"
                onClick={() => setPubSource('upload')}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  pubSource === 'upload'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Upload public_key.pem
              </button>
            </div>

            {pubSource === 'session' ? (
              <div className="mt-3 text-xs text-slate-300 bg-slate-950/80 border border-slate-800 rounded-lg p-3">
                {activeKeypair ? (
                  <span>
                    Using session <span className="font-semibold text-white">{activeKeypair.algorithm}</span> public key ·{' '}
                    <span className="font-mono text-emerald-400">
                      {activeKeypair.fingerprint_sha256.slice(0, 24)}...
                    </span>
                  </span>
                ) : (
                  <span className="text-amber-400">
                    No active session key. Click 1-Click Quick-Start Demo in the sidebar or upload public_key.pem.
                  </span>
                )}
              </div>
            ) : (
              <div className="mt-3">
                <label className="flex items-center justify-center gap-2 px-4 py-3 bg-slate-950 border border-dashed border-slate-700 hover:border-blue-500 rounded-lg text-xs text-slate-300 cursor-pointer">
                  <Upload className="w-4 h-4 text-emerald-400" />
                  <span>{uploadedPubKeyName ? `Loaded: ${uploadedPubKeyName}` : 'Choose public_key.pem file'}</span>
                  <input type="file" accept=".pem,.pub,.txt" onChange={handlePublicKeyUpload} className="hidden" />
                </label>
              </div>
            )}
          </div>

          <div className="border-t border-slate-800 pt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-slate-200">Payload to Verify</span>
              {payloadMode === 'text' && (
                <button
                  type="button"
                  onClick={onSimulateTampering}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <FlaskConical className="w-3.5 h-3.5" />
                  <span>Simulate Tampering</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 border border-slate-800 rounded-lg mb-3">
              <button
                type="button"
                onClick={() => setPayloadMode('text')}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  payloadMode === 'text'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Text Message (UTF-8)
              </button>
              <button
                type="button"
                onClick={() => setPayloadMode('file')}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  payloadMode === 'file'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Binary File Upload
              </button>
            </div>

            {payloadMode === 'text' ? (
              <div>
                <label htmlFor="verify-payload-textarea" className="sr-only">
                  Verify Message Payload
                </label>
                <textarea
                  id="verify-payload-textarea"
                  rows={6}
                  value={verifyText}
                  onChange={(e) => onChangeVerifyText(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs font-mono text-slate-100 focus:outline-none focus:border-blue-500 leading-relaxed"
                  placeholder="Enter or modify message payload to test verification..."
                />
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center gap-2 px-4 py-6 bg-slate-950 border border-dashed border-slate-700 hover:border-blue-500 rounded-lg text-xs text-slate-300 cursor-pointer">
                <FileText className="w-5 h-5 text-blue-400" />
                <span>
                  {uploadedVerifyFileName ? `Loaded: ${uploadedVerifyFileName}` : 'Upload binary file to verify'}
                </span>
                <input type="file" onChange={handleVerifyFileUpload} className="hidden" />
              </label>
            )}
          </div>

          <div className="border-t border-slate-800 pt-4">
            <span className="block text-sm font-medium text-slate-200 mb-2">Detached Signature Source</span>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 border border-slate-800 rounded-lg mb-3">
              <button
                type="button"
                onClick={() => setSigSource('b64')}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  sigSource === 'b64'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Paste Base64 Signature
              </button>
              <button
                type="button"
                onClick={() => setSigSource('bundle')}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  sigSource === 'bundle'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Upload .sig.json Bundle
              </button>
            </div>

            {sigSource === 'b64' ? (
              <div>
                <label htmlFor="verify-signature-b64" className="sr-only">
                  Base64 Signature String
                </label>
                <textarea
                  id="verify-signature-b64"
                  rows={3}
                  value={verifySignatureB64}
                  onChange={(e) => onChangeVerifySignatureB64(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs font-mono text-blue-300 focus:outline-none focus:border-blue-500"
                  placeholder="Paste detached Base64 signature here..."
                />
              </div>
            ) : (
              <label className="flex items-center justify-center gap-2 px-4 py-4 bg-slate-950 border border-dashed border-slate-700 hover:border-blue-500 rounded-lg text-xs text-slate-300 cursor-pointer">
                <Upload className="w-4 h-4 text-blue-400" />
                <span>{uploadedBundleName ? `Loaded: ${uploadedBundleName}` : 'Upload <name>.sig.json file'}</span>
                <input type="file" accept=".json" onChange={handleBundleUpload} className="hidden" />
              </label>
            )}
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{isLoading ? 'Verifying...' : 'Verify Cryptographic Signature'}</span>
          </button>
        </form>

        <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-5">
          <h3 className="text-sm font-semibold text-slate-200">Cryptographic Verification Verdict</h3>

          {!verifyResult ? (
            <div className="py-12 text-center space-y-3">
              <ShieldCheck className="w-8 h-8 text-slate-500 mx-auto" />
              <div className="text-sm font-medium text-slate-300">Awaiting Verification Check</div>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Click Verify Cryptographic Signature or use the 1-Click Quick-Start Demo in the sidebar to evaluate authenticity and payload integrity.
              </p>
            </div>
          ) : (
            <div className="space-y-5" data-testid="verification-verdict-panel">
              {verifyResult.is_valid ? (
                <div
                  role="status"
                  className="bg-emerald-950/90 border-2 border-emerald-500 rounded-xl p-5 space-y-1.5"
                >
                  <div className="flex items-center gap-2.5 text-emerald-300 font-bold text-lg">
                    <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0" />
                    <span>SIGNATURE VALID</span>
                  </div>
                  <p className="text-xs text-emerald-100/90 leading-relaxed">
                    Authenticity &amp; Integrity Confirmed — The payload matches the detached cryptographic signature generated by the holder of the private key.
                  </p>
                </div>
              ) : (
                <div
                  role="alert"
                  className="bg-red-950/90 border-2 border-red-500 rounded-xl p-5 space-y-1.5"
                >
                  <div className="flex items-center gap-2.5 text-red-200 font-bold text-lg">
                    <ShieldAlert className="w-6 h-6 text-red-400 shrink-0" />
                    <span>SIGNATURE INVALID / TAMPERED</span>
                  </div>
                  <p className="text-xs text-red-100/90 leading-relaxed">
                    Cryptographic Verification Failed — Do NOT trust this payload. Either a byte was altered, the signature is corrupted, or the public key does not match the signer.
                  </p>
                </div>
              )}

              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 text-xs text-slate-300">
                <span className="font-semibold text-slate-100">Diagnostic Reason: </span>
                <span>{verifyResult.reason}</span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5">
                  <div className="text-xs text-slate-400">Detected Key Algorithm</div>
                  <div className="text-base font-semibold text-slate-100 mt-1 font-mono">
                    {verifyResult.algorithm}
                  </div>
                </div>
                <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5">
                  <div className="text-xs text-slate-400">Verification Status</div>
                  <div
                    className={`text-base font-semibold mt-1 font-mono ${
                      verifyResult.is_valid ? 'text-emerald-400' : 'text-red-400'
                    }`}
                  >
                    {verifyResult.is_valid ? 'AUTHENTIC' : 'REJECTED'}
                  </div>
                </div>
              </div>

              <div>
                <div className="text-xs font-medium text-slate-300 mb-1">Computed Payload SHA-256 Digest</div>
                <pre className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-slate-200 break-all whitespace-pre-wrap select-all">
                  {verifyResult.payload_sha256}
                </pre>
              </div>

              <div>
                <div className="text-xs font-medium text-slate-300 mb-1">Public Key SHA-256 Fingerprint</div>
                <pre className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-emerald-400 break-all whitespace-pre-wrap select-all">
                  {verifyResult.public_key_fingerprint}
                </pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
