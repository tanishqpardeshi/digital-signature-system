import React from 'react';
import { Shield, Lock, FileCheck2 } from 'lucide-react';

export const ArchitectureTab: React.FC = () => {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold text-slate-100">How It Works &amp; Cryptographic Architecture</h2>
        <p className="text-sm text-slate-400 mt-1">
          Core security guarantees of asymmetric digital signatures and side-by-side comparison of Ed25519 vs. RSA-2048 (RSASSA-PSS + SHA-256).
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-2.5">
          <div className="flex items-center gap-2.5 text-blue-400 font-semibold text-sm">
            <Shield className="w-4 h-4" />
            <span>01. Authenticity</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Cryptographically proves <strong>who</strong> originated the payload. Because only the signer holds the private key, a signature verified against their public key binds the message to that specific key pair.
          </p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-2.5">
          <div className="flex items-center gap-2.5 text-emerald-400 font-semibold text-sm">
            <FileCheck2 className="w-4 h-4" />
            <span>02. Integrity</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Guarantees <strong>zero silent tampering</strong>. Modifying even a single bit in a multi-megabyte file completely changes its SHA-256 digest (Avalanche Effect), causing signature verification to immediately reject the altered payload.
          </p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-2.5">
          <div className="flex items-center gap-2.5 text-amber-400 font-semibold text-sm">
            <Lock className="w-4 h-4" />
            <span>03. Non-Repudiation</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Prevents the signer from denying they authorized a transaction or software release, provided the private key remained protected and bound to their identity via a Public Key Infrastructure (PKI).
          </p>
        </div>
      </div>

      <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800">
          <h3 className="text-sm font-semibold text-slate-100">
            Algorithm Comparison: Ed25519 vs. RSA-2048 (RSASSA-PSS + SHA-256)
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-300">
                <th className="py-3 px-4 font-semibold">Dimension</th>
                <th className="py-3 px-4 font-semibold text-blue-400">Ed25519 (Recommended Default)</th>
                <th className="py-3 px-4 font-semibold text-emerald-400">RSA-2048 (PSS + SHA-256)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-slate-300">
              <tr>
                <td className="py-3 px-4 font-medium text-slate-200">Mathematical Basis</td>
                <td className="py-3 px-4">Twisted Edwards Curve (Curve25519 / RFC 8032)</td>
                <td className="py-3 px-4">Integer Factorization (2048-bit modulus, e = 65537)</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-200">Public Key Size</td>
                <td className="py-3 px-4 font-mono tabular-nums">32 bytes (44 bytes DER SPKI)</td>
                <td className="py-3 px-4 font-mono tabular-nums">256 bytes (294 bytes DER SPKI)</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-200">Detached Signature Size</td>
                <td className="py-3 px-4 font-mono tabular-nums">64 bytes (88 Base64 chars)</td>
                <td className="py-3 px-4 font-mono tabular-nums">256 bytes (344 Base64 chars)</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-200">Padding &amp; Nonce Safety</td>
                <td className="py-3 px-4">Deterministic hash-derived nonce (immune to bad RNG)</td>
                <td className="py-3 px-4">Probabilistic RSASSA-PSS with MGF1(SHA-256) &amp; max salt</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-200">Key Generation Latency</td>
                <td className="py-3 px-4 font-mono tabular-nums">&lt; 1 ms</td>
                <td className="py-3 px-4 font-mono tabular-nums">40 ms – 250 ms (random prime search)</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-medium text-slate-200">Side-Channel Profile</td>
                <td className="py-3 px-4">Constant-time curve arithmetic without secret branches</td>
                <td className="py-3 px-4">Requires RSA blinding &amp; strict PSS padding checks</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-3">
        <h3 className="text-sm font-semibold text-slate-100">
          Real-World Public Key Infrastructure (PKI) &amp; Certificate Authorities
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          While a valid signature proves that the holder of the matching private key signed a document, verifiers must also ensure the public key itself was not substituted by an active Man-in-the-Middle (MitM) attacker:
        </p>
        <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside leading-relaxed">
          <li>
            <strong>Out-of-Band SHA-256 Key Fingerprints:</strong> Verifiers compare the colon-separated uppercase hexadecimal SHA-256 digest of the DER-encoded <code className="text-emerald-400">SubjectPublicKeyInfo</code> across an authenticated channel.
          </li>
          <li>
            <strong>X.509 Certificates &amp; Certificate Authorities (CAs):</strong> In TLS, S/MIME, and code signing, a trusted Root or Intermediate CA signs an X.509 certificate binding the subject&apos;s identity to their public key.
          </li>
          <li>
            <strong>Hardware Security Modules (HSMs) &amp; Client-Side Signing:</strong> Production private keys reside inside non-exportable hardware tokens (YubiKey, CloudHSM, TPM, Secure Enclave) so signing occurs strictly on the client device.
          </li>
        </ul>
      </div>
    </div>
  );
};
