import React, { useState } from 'react';
import { PenTool, Download, Upload, FileText, ChevronDown, ChevronUp, Copy, Check } from 'lucide-react';
import { KeyPair, PayloadType, SignatureBundleData } from '../types';

interface SignTabProps {
  activeKeypair: KeyPair | null;
  activePassphrase: string;
  signText: string;
  onChangeSignText: (val: string) => void;
  lastBundle: SignatureBundleData | null;
  lastBundleJson: string;
  onSignPayload: (params: {
    private_pem: string;
    passphrase: string;
    payload_type: PayloadType;
    text?: string;
    data_b64?: string;
    filename: string | null;
  }) => Promise<void>;
  isLoading: boolean;
}

export const SignTab: React.FC<SignTabProps> = ({
  activeKeypair,
  activePassphrase,
  signText,
  onChangeSignText,
  lastBundle,
  lastBundleJson,
  onSignPayload,
  isLoading,
}) => {
  const [keySource, setKeySource] = useState<'session' | 'upload'>('session');
  const [uploadedPrivatePem, setUploadedPrivatePem] = useState<string>('');
  const [uploadedKeyName, setUploadedKeyName] = useState<string>('');
  const [passphraseInput, setPassphraseInput] = useState<string>('');
  const [payloadMode, setPayloadMode] = useState<PayloadType>('text');
  const [uploadedFileB64, setUploadedFileB64] = useState<string>('');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [uploadedFileSize, setUploadedFileSize] = useState<number>(0);
  const [showJsonPreview, setShowJsonPreview] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedSig, setCopiedSig] = useState<boolean>(false);

  const handlePrivateKeyFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadedKeyName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedPrivatePem(typeof reader.result === 'string' ? reader.result : '');
    };
    reader.readAsText(file);
  };

  const handleBinaryPayloadFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadedFileName(file.name);
    setUploadedFileSize(file.size);
    const reader = new FileReader();
    reader.onload = () => {
      const arrayBuffer = reader.result as ArrayBuffer;
      const bytes = new Uint8Array(arrayBuffer);
      let binary = '';
      for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      setUploadedFileB64(btoa(binary));
    };
    reader.readAsArrayBuffer(file);
  };

  const handleSignSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const privatePem = keySource === 'session' ? activeKeypair?.private_pem || '' : uploadedPrivatePem;
    const effectivePassphrase =
      keySource === 'session'
        ? passphraseInput || activePassphrase
        : passphraseInput;

    if (!privatePem.trim()) {
      setErrorMsg('No private key available. Generate a session key in Tab 1 or upload a private_key.pem file.');
      return;
    }

    if (payloadMode === 'text') {
      if (!signText.trim()) {
        setErrorMsg('Message payload cannot be empty.');
        return;
      }
      try {
        await onSignPayload({
          private_pem: privatePem,
          passphrase: effectivePassphrase,
          payload_type: 'text',
          text: signText,
          filename: 'message.txt',
        });
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : String(err));
      }
    } else {
      if (!uploadedFileB64) {
        setErrorMsg('Please upload a binary file to sign.');
        return;
      }
      try {
        await onSignPayload({
          private_pem: privatePem,
          passphrase: effectivePassphrase,
          payload_type: 'file',
          data_b64: uploadedFileB64,
          filename: uploadedFileName || 'artifact.bin',
        });
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : String(err));
      }
    }
  };

  const handleDownloadSigBundle = () => {
    if (!lastBundle || !lastBundleJson) return;
    const baseName = (lastBundle.filename || 'payload').replace(/\.[^/.]+$/, '');
    const sigFilename = `${baseName}.sig.json`;
    const blob = new Blob([lastBundleJson], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = sigFilename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleCopySignature = () => {
    if (!lastBundle) return;
    navigator.clipboard.writeText(lastBundle.signature_b64);
    setCopiedSig(true);
    setTimeout(() => setCopiedSig(false), 1800);
  };

  const downloadFileName = lastBundle
    ? `${(lastBundle.filename || 'payload').replace(/\.[^/.]+$/, '')}.sig.json`
    : 'payload.sig.json';

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-100">Create Detached Cryptographic Signature</h2>
        <p className="text-sm text-slate-400 mt-1">
          Sign UTF-8 text or raw binary files using your active session key or an uploaded PKCS#8 .pem private key.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleSignSubmit}
          className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-5"
        >
          <div>
            <span className="block text-sm font-medium text-slate-200 mb-2">Private Key Source</span>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 border border-slate-800 rounded-lg">
              <button
                type="button"
                onClick={() => setKeySource('session')}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  keySource === 'session'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Use Active Session Key
              </button>
              <button
                type="button"
                onClick={() => setKeySource('upload')}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  keySource === 'upload'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Upload Private Key (.pem)
              </button>
            </div>

            {keySource === 'session' ? (
              <div className="mt-3 text-xs text-slate-300 bg-slate-950/80 border border-slate-800 rounded-lg p-3">
                {activeKeypair ? (
                  <div className="space-y-1">
                    <div>
                      Using session <span className="font-semibold text-white">{activeKeypair.algorithm}</span> key ·{' '}
                      <span className="font-mono text-emerald-400">
                        {activeKeypair.fingerprint_sha256.slice(0, 24)}...
                      </span>
                    </div>
                    {activeKeypair.encrypted && (
                      <div className="pt-2">
                        <label htmlFor="session-sign-passphrase" className="block text-xs text-slate-400 mb-1">
                          Passphrase for Encrypted Session Private Key
                        </label>
                        <input
                          id="session-sign-passphrase"
                          type="password"
                          value={passphraseInput}
                          onChange={(e) => setPassphraseInput(e.target.value)}
                          placeholder="Enter key passphrase..."
                          className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-100"
                        />
                      </div>
                    )}
                  </div>
                ) : (
                  <span className="text-amber-400">
                    No active session key loaded. Generate one in Tab 1 or click 1-Click Quick-Start Demo.
                  </span>
                )}
              </div>
            ) : (
              <div className="mt-3 space-y-3">
                <label className="flex items-center justify-center gap-2 px-4 py-3 bg-slate-950 border border-dashed border-slate-700 hover:border-blue-500 rounded-lg text-xs text-slate-300 cursor-pointer">
                  <Upload className="w-4 h-4 text-blue-400" />
                  <span>{uploadedKeyName ? `Loaded: ${uploadedKeyName}` : 'Choose private_key.pem file'}</span>
                  <input type="file" accept=".pem,.key,.txt" onChange={handlePrivateKeyFile} className="hidden" />
                </label>
                <div>
                  <label htmlFor="upload-sign-passphrase" className="block text-xs text-slate-400 mb-1">
                    Private Key Passphrase (if encrypted)
                  </label>
                  <input
                    id="upload-sign-passphrase"
                    type="password"
                    value={passphraseInput}
                    onChange={(e) => setPassphraseInput(e.target.value)}
                    placeholder="Leave empty if unencrypted..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100"
                  />
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-slate-800 pt-4">
            <span className="block text-sm font-medium text-slate-200 mb-2">Payload Input Mode</span>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 border border-slate-800 rounded-lg mb-3">
              <button
                type="button"
                onClick={() => setPayloadMode('text')}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  payloadMode === 'text'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Text Message (UTF-8)
              </button>
              <button
                type="button"
                onClick={() => setPayloadMode('file')}
                className={`px-3 py-2 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  payloadMode === 'file'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Binary File Upload
              </button>
            </div>

            {payloadMode === 'text' ? (
              <div>
                <label htmlFor="sign-message-textarea" className="block text-xs font-medium text-slate-300 mb-1.5">
                  Message Payload to Sign
                </label>
                <textarea
                  id="sign-message-textarea"
                  rows={7}
                  value={signText}
                  onChange={(e) => onChangeSignText(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs font-mono text-slate-100 focus:outline-none focus:border-blue-500 leading-relaxed"
                  placeholder="Enter UTF-8 message payload to sign..."
                />
              </div>
            ) : (
              <div>
                <label className="flex flex-col items-center justify-center gap-2 px-4 py-8 bg-slate-950 border border-dashed border-slate-700 hover:border-blue-500 rounded-lg text-xs text-slate-300 cursor-pointer">
                  <FileText className="w-6 h-6 text-blue-400" />
                  <span>
                    {uploadedFileName
                      ? `${uploadedFileName} (${uploadedFileSize.toLocaleString()} bytes)`
                      : 'Select any binary or text file to sign raw bytes'}
                  </span>
                  <input type="file" onChange={handleBinaryPayloadFile} className="hidden" />
                </label>
              </div>
            )}
          </div>

          {errorMsg && (
            <div className="p-3 bg-red-950/80 border border-red-800 rounded-lg text-xs text-red-200">
              {errorMsg}
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <PenTool className="w-4 h-4" />
            <span>{isLoading ? 'Signing Payload...' : 'Generate Detached Signature'}</span>
          </button>
        </form>

        <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-xl p-6 space-y-5">
          {!lastBundle ? (
            <div className="py-12 text-center space-y-3">
              <PenTool className="w-8 h-8 text-slate-500 mx-auto" />
              <div className="text-sm font-medium text-slate-300">No Signature Bundle Generated Yet</div>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Sign a message or binary file on the left to compute the SHA-256 payload digest, Base64 detached signature, and canonical .sig.json bundle.
              </p>
            </div>
          ) : (
            <>
              <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-800">
                <div>
                  <div className="text-xs text-slate-400">Detached Signature Telemetry</div>
                  <div className="text-sm text-slate-200 mt-1 flex items-center gap-2">
                    <span className="font-semibold text-white">{lastBundle.algorithm}</span>
                    <span aria-hidden="true">·</span>
                    <span>Payload: {lastBundle.payload_type}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-xs text-slate-400 tabular-nums">{lastBundle.signed_at}</span>
                  </div>
                </div>
              </div>

              <div>
                <div className="text-xs font-medium text-slate-300 mb-1">Payload SHA-256 Digest</div>
                <pre className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-slate-200 break-all whitespace-pre-wrap select-all">
                  {lastBundle.payload_sha256}
                </pre>
              </div>

              <div>
                <div className="text-xs font-medium text-slate-300 mb-1">Signer Public Key Fingerprint (SHA-256)</div>
                <pre className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-emerald-400 break-all whitespace-pre-wrap select-all">
                  {lastBundle.public_key_fingerprint}
                </pre>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium text-slate-300">Detached Signature (Base64)</span>
                  <button
                    type="button"
                    onClick={handleCopySignature}
                    className="inline-flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300 cursor-pointer whitespace-nowrap"
                  >
                    {copiedSig ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedSig ? 'Copied' : 'Copy Base64'}</span>
                  </button>
                </div>
                <pre className="bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-blue-300 overflow-x-auto break-all whitespace-pre-wrap select-all">
                  {lastBundle.signature_b64}
                </pre>
              </div>

              <div className="border border-slate-800 rounded-lg overflow-hidden">
                <button
                  type="button"
                  onClick={() => setShowJsonPreview(!showJsonPreview)}
                  aria-expanded={showJsonPreview}
                  className="w-full flex items-center justify-between px-4 py-2.5 bg-slate-950/70 hover:bg-slate-950 text-xs font-medium text-slate-200 cursor-pointer"
                >
                  <span>Preview Canonical {downloadFileName} Bundle (sort_keys=True)</span>
                  {showJsonPreview ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
                {showJsonPreview && (
                  <pre className="p-3.5 bg-slate-950 text-xs font-mono text-slate-300 overflow-x-auto">
                    {lastBundleJson}
                  </pre>
                )}
              </div>

              <button
                type="button"
                onClick={handleDownloadSigBundle}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-100 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                <Download className="w-4 h-4 text-blue-400" />
                <span>Download {downloadFileName}</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
