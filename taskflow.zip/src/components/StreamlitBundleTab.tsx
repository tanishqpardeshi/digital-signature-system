import React, { useState } from 'react';
import { Copy, Check, Download, FileCode, Terminal } from 'lucide-react';
import { ProjectSourceFile } from '../types';

interface StreamlitBundleTabProps {
  files: ProjectSourceFile[];
}

export const StreamlitBundleTab: React.FC<StreamlitBundleTabProps> = ({ files }) => {
  const [selectedPath, setSelectedPath] = useState<string>(
    files[0]?.path || 'digital-signature-system/app.py'
  );
  const [copiedPath, setCopiedPath] = useState<string | null>(null);

  const activeFile = files.find((f) => f.path === selectedPath) || files[0];

  const handleCopyFile = (file: ProjectSourceFile) => {
    navigator.clipboard.writeText(file.content);
    setCopiedPath(file.path);
    setTimeout(() => setCopiedPath(null), 1800);
  };

  const handleDownloadFile = (file: ProjectSourceFile) => {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = file.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-100">
            Deploy-Ready Python &amp; Streamlit Repository Bundle
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Inspect, copy, or download all 6 production files generated under <code className="text-blue-400">digital-signature-system/</code> for GitHub and Streamlit Community Cloud.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-3 py-1.5 rounded-lg">
          <Terminal className="w-3.5 h-3.5" />
          <span>python -m unittest discover tests -v (9/9 passing)</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-4 bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-2">
          <div className="text-xs font-semibold text-slate-400 px-2 pb-1">
            Repository File Tree (digital-signature-system/)
          </div>
          {files.map((file) => {
            const isSelected = activeFile?.path === file.path;
            return (
              <button
                key={file.path}
                type="button"
                onClick={() => setSelectedPath(file.path)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-left text-xs transition-colors cursor-pointer ${
                  isSelected
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800/80'
                }`}
              >
                <span className="flex items-center gap-2 truncate">
                  <FileCode className="w-4 h-4 shrink-0" />
                  <span className="font-mono truncate">{file.path.replace('digital-signature-system/', '')}</span>
                </span>
                <span
                  className={`font-mono text-[11px] tabular-nums shrink-0 ml-2 ${
                    isSelected ? 'text-blue-100' : 'text-slate-400'
                  }`}
                >
                  {file.lines}L
                </span>
              </button>
            );
          })}
        </div>

        <div className="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden">
          {activeFile && (
            <>
              <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 bg-slate-950 border-b border-slate-800">
                <div className="font-mono text-xs text-slate-200">
                  ### file: {activeFile.path}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopyFile(activeFile)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
                  >
                    {copiedPath === activeFile.path ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy File</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDownloadFile(activeFile)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download {activeFile.filename}</span>
                  </button>
                </div>
              </div>
              <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto max-h-[540px] leading-relaxed">
                {activeFile.content}
              </pre>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
