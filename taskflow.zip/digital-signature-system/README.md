# 🔐 Digital Signature Verification System

A modular, production-grade **Digital Signature Verification System** built with Python, **Streamlit**, and the official [`cryptography`](https://cryptography.io/) library. Designed for strict separation of concerns, zero disk persistence of sensitive keys, and one-click deployment to **Streamlit Community Cloud**.

---

## ✨ Key Capabilities

- **Standards-Compliant Asymmetric Algorithms**:
  - **Ed25519 (RFC 8032)** *(Recommended Default)*: Fast, compact 32-byte keys, deterministic 64-byte detached signatures, immune to weak-RNG nonce reuse.
  - **RSA-2048 (RSASSA-PSS + SHA-256)**: 2048-bit modulus (`e = 65537`), signed and verified using probabilistic `PSS` padding (`MGF1(SHA-256)`, `salt_length=PSS.MAX_LENGTH`) and `SHA-256`.
- **PKCS#8 Private Key Protection**: Optional passphrase encryption using `BestAvailableEncryption` and `SubjectPublicKeyInfo` PEM public key serialization.
- **Colon-Separated SHA-256 Key Fingerprints**: Computes SHA-256 over the DER-encoded `SubjectPublicKeyInfo` formatted in uppercase 4-character hex blocks (`XXXX:XXXX:...`).
- **Canonical `.sig.json` Signature Bundles**: Deterministic JSON serialization (`sort_keys=True`) bundling the Base64 signature, SHA-256 payload digest, key fingerprint, UTC ISO-8601 timestamp, and payload metadata.
- **Interactive Tamper Laboratory**: Includes a **1-Click Quick-Start Demo** in the sidebar and a **1-Click "Simulate Tampering"** button in the Verify tab to demonstrate the SHA-256 avalanche effect and cryptographic rejection in real time.

---

## 🏗️ System Architecture

The cryptographic core (`crypto_core.py`) has **zero Streamlit imports**, allowing it to be unit-tested independently or reused directly inside a FastAPI service, CLI tool, or CI/CD pipeline.

```text
+-----------------------------------------------------------------------------------+
|                        Streamlit Web UI (app.py)                                  |
|  +-------------------+  +-------------------+  +-------------------------------+  |
|  | Sidebar:          |  | Tab 1: Key Mgmt   |  | Tab 2: Sign Message / File    |  |
|  | - 1-Click Demo    |  | Tab 3: Verify &   |  | Tab 4: Architecture & PKI     |  |
|  | - Active Key Card |  |   Tamper Test     |  |                               |  |
|  | - Activity Log    |  +-------------------+  +-------------------------------+  |
+-----------------------------------------+-----------------------------------------+
                                          | In-Memory Bytes & Dataclasses
                                          v
+-----------------------------------------------------------------------------------+
|                  Pure Python Cryptographic Engine (crypto_core.py)                |
|                                                                                   |
|  +-----------------------+   +-----------------------+   +---------------------+  |
|  | generate_keypair()    |   | sign_bytes()          |   | verify_bytes()      |  |
|  | - Ed25519 / RSA-2048  |   | - Auto-detects key    |   | - Auto-detects key  |  |
|  | - PKCS#8 Encryption   |   | - SHA-256 Digest      |   | - Graceful error    |  |
|  | - DER SHA-256 Fp      |   | - SignatureBundle     |   |   handling          |  |
|  +-----------------------+   +-----------------------+   +---------------------+  |
+-----------------------------------------+-----------------------------------------+
                                          |
                                          v
+-----------------------------------------------------------------------------------+
|                pyca/cryptography (>=43.0.0) & OpenSSL Backend                     |
+-----------------------------------------------------------------------------------+
```

### Mermaid Data-Flow Diagram

```mermaid
sequenceDiagram
    autonumber
    actor User
    participant UI as Streamlit UI (app.py)
    participant Core as Crypto Engine (crypto_core.py)
    participant Lib as pyca/cryptography

    User->>UI: Generate Key Pair (Ed25519 / RSA-2048 + Optional Passphrase)
    UI->>Core: generate_keypair(algorithm, passphrase)
    Core->>Lib: Generate Private/Public Keys & DER Fingerprint
    Lib-->>Core: PKCS#8 Private PEM + SPKI Public PEM
    Core-->>UI: KeyPair Dataclass (Stored in st.session_state)

    User->>UI: Sign Text or Binary File
    UI->>Core: sign_bytes(private_pem, raw_bytes, passphrase)
    Core->>Lib: Sign with Ed25519 or RSA-PSS(MGF1-SHA256)
    Lib-->>Core: Raw Signature Bytes
    Core-->>UI: SignatureBundle (.sig.json)

    User->>UI: Verify Payload / Click "Simulate Tampering"
    UI->>Core: verify_bytes(public_pem, payload_bytes, signature_b64)
    Core->>Lib: Verify Signature against Public Key & Payload
    Lib-->>Core: Valid or InvalidSignature Exception
    Core-->>UI: VerificationResult (is_valid, reason, digests)
```

---

## 📁 Project Structure

```text
digital-signature-system/
├── app.py                     # Streamlit web interface (4 tabs + sidebar)
├── crypto_core.py             # Pure Python cryptographic engine & dataclasses
├── requirements.txt           # Pinned dependencies for Streamlit Community Cloud
├── .streamlit/
│   └── config.toml            # Clean, high-contrast modern theme
├── tests/
│   └── test_crypto_core.py    # Comprehensive unittest suite (9 test cases)
└── README.md                  # Architecture, local setup, deployment & security notes
```

---

## 🚀 Local Setup & Execution

### 1. Install Dependencies

```bash
cd digital-signature-system
pip install -r requirements.txt
```

### 2. Run Automated Unit Tests

```bash
python -m unittest discover tests -v
```

### 3. Launch the Streamlit Application

```bash
streamlit run app.py
```

The app will open in your browser at `http://localhost:8501`.

---

## ☁️ Deploying to Streamlit Community Cloud

1. Push the `digital-signature-system/` repository to GitHub.
2. Sign in to [Streamlit Community Cloud](https://share.streamlit.io/) and click **Create app**.
3. Select your GitHub repository, branch (`main`), and set **Main file path** to `app.py` (or `digital-signature-system/app.py` if deployed from a monorepo root).
4. Click **Deploy**. Streamlit Community Cloud automatically detects `requirements.txt` and `.streamlit/config.toml`.

---

## 🛡️ Security Trade-Offs: Client-Side vs. Server-Side Signing

- **Strictly In-Memory Processing**: This application processes all private keys, passphrases, and payloads exclusively in volatile RAM (`st.session_state`). No keys or messages are ever written to disk or printed to application logs.
- **Why Production Signing Must Happen Locally on the Client**:
  - In a hosted web application (like Streamlit Community Cloud), uploading a private key transmits it over TLS to the application server's memory.
  - In high-assurance production systems (such as code signing, banking transactions, or TLS certificate issuance), **private keys must never leave the client device**.
  - Production architectures keep private keys inside hardware security modules (**HSMs**), smart cards (**YubiKey / PIV**), OS keychains (**Secure Enclave / TPM**), or execute signing locally via a CLI / WebCrypto browser context so only the **public key** and **detached signature** are transmitted to the verification server.
