"""
test_crypto_core.py — Automated Unit Test Suite for crypto_core.py.

Run via:
    python -m unittest discover tests -v
"""

from __future__ import annotations

import json
import os
import sys
import unittest

# Ensure parent project root is importable when running `python -m unittest discover tests -v`
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from crypto_core import (
    KeyPair,
    SignatureBundle,
    VerificationResult,
    compute_sha256_hex,
    generate_keypair,
    public_key_fingerprint,
    sign_bytes,
    verify_bytes,
)


class TestCryptoCore(unittest.TestCase):
    """Comprehensive unit tests covering Ed25519, RSA-2048 (PSS + SHA-256), tampering, and serialization."""

    def test_01_ed25519_sign_and_verify_with_passphrase(self) -> None:
        """Valid Ed25519 key generation with PKCS#8 passphrase encryption, signing, and verification."""
        passphrase = "correct-horse-battery-staple"
        kp: KeyPair = generate_keypair(algorithm="Ed25519", passphrase=passphrase)

        self.assertEqual(kp.algorithm, "Ed25519")
        self.assertTrue(kp.encrypted)
        self.assertIn("BEGIN ENCRYPTED PRIVATE KEY", kp.private_pem)
        self.assertIn("BEGIN PUBLIC KEY", kp.public_pem)
        self.assertEqual(len(kp.fingerprint_sha256.split(":")), 16)

        payload = b"Authorize wire transfer of $48,500.00 USD to IBAN DE89-3704-0044."
        bundle = sign_bytes(
            private_pem=kp.private_pem,
            data=payload,
            passphrase=passphrase,
            payload_type="text",
            filename="wire_transfer.txt",
        )

        self.assertEqual(bundle.algorithm, "Ed25519")
        self.assertEqual(bundle.public_key_fingerprint, kp.fingerprint_sha256)
        self.assertEqual(bundle.payload_sha256, compute_sha256_hex(payload))

        result: VerificationResult = verify_bytes(
            public_pem=kp.public_pem,
            data=payload,
            signature_b64=bundle.signature_b64,
        )
        self.assertTrue(result.is_valid)
        self.assertEqual(result.algorithm, "Ed25519")
        self.assertEqual(result.public_key_fingerprint, kp.fingerprint_sha256)
        self.assertEqual(result.payload_sha256, bundle.payload_sha256)

    def test_02_rsa2048_pss_sign_and_verify(self) -> None:
        """Valid RSA-2048 key generation, RSASSA-PSS + SHA-256 signing, and verification."""
        kp = generate_keypair(algorithm="RSA-2048", passphrase="")
        self.assertEqual(kp.algorithm, "RSA-2048")
        self.assertFalse(kp.encrypted)
        self.assertIn("BEGIN PRIVATE KEY", kp.private_pem)

        payload = b"RSA-2048 PSS with MGF1(SHA-256) and max salt length verification payload."
        bundle = sign_bytes(private_pem=kp.private_pem, data=payload, passphrase="")
        self.assertEqual(bundle.algorithm, "RSA-2048")

        result = verify_bytes(
            public_pem=kp.public_pem,
            data=payload,
            signature_b64=bundle.signature_b64,
        )
        self.assertTrue(result.is_valid)
        self.assertEqual(result.algorithm, "RSA-2048")

    def test_03_single_byte_message_tampering_fails_both_algorithms(self) -> None:
        """Single-byte payload tampering must fail verification for both Ed25519 and RSA-2048."""
        original = b"Contract amount: $10,000.00"
        tampered = b"Contract amount: $90,000.00"

        for alg in ("Ed25519", "RSA-2048"):
            with self.subTest(algorithm=alg):
                kp = generate_keypair(algorithm=alg)
                bundle = sign_bytes(private_pem=kp.private_pem, data=original)
                tampered_result = verify_bytes(
                    public_pem=kp.public_pem,
                    data=tampered,
                    signature_b64=bundle.signature_b64,
                )
                self.assertFalse(tampered_result.is_valid)
                self.assertIn("failed", tampered_result.reason.lower())

    def test_04_wrong_public_key_fails_verification(self) -> None:
        """Verifying a valid signature with a different public key must fail cleanly."""
        alice_kp = generate_keypair(algorithm="Ed25519")
        mallory_kp = generate_keypair(algorithm="Ed25519")
        payload = b"Signed exclusively by Alice."

        bundle = sign_bytes(private_pem=alice_kp.private_pem, data=payload)
        wrong_key_result = verify_bytes(
            public_pem=mallory_kp.public_pem,
            data=payload,
            signature_b64=bundle.signature_b64,
        )
        self.assertFalse(wrong_key_result.is_valid)
        self.assertEqual(wrong_key_result.public_key_fingerprint, mallory_kp.fingerprint_sha256)

    def test_05_corrupted_signature_and_invalid_base64_fail_gracefully(self) -> None:
        """Malformed Base64, corrupted signature bytes, or invalid PEM must not raise unhandled exceptions."""
        kp = generate_keypair(algorithm="Ed25519")
        payload = b"Resilience test against malformed inputs."
        bundle = sign_bytes(private_pem=kp.private_pem, data=payload)

        # Case A: Malformed Base64 characters
        bad_b64_result = verify_bytes(
            public_pem=kp.public_pem,
            data=payload,
            signature_b64="!!!NOT_VALID_BASE64***",
        )
        self.assertFalse(bad_b64_result.is_valid)
        self.assertIn("base64", bad_b64_result.reason.lower())

        # Case B: Valid Base64 but flipped byte in decoded signature
        flipped_b64 = ("A" if not bundle.signature_b64.startswith("A") else "B") + bundle.signature_b64[1:]
        corrupted_sig_result = verify_bytes(
            public_pem=kp.public_pem,
            data=payload,
            signature_b64=flipped_b64,
        )
        self.assertFalse(corrupted_sig_result.is_valid)

        # Case C: Corrupted Public Key PEM
        bad_pem_result = verify_bytes(
            public_pem="-----BEGIN PUBLIC KEY-----\nCORRUPTED\n-----END PUBLIC KEY-----",
            data=payload,
            signature_b64=bundle.signature_b64,
        )
        self.assertFalse(bad_pem_result.is_valid)
        self.assertIn("pem", bad_pem_result.reason.lower())

    def test_06_wrong_passphrase_raises_value_error(self) -> None:
        """Supplying an incorrect or empty passphrase for an encrypted private key must raise ValueError."""
        kp = generate_keypair(algorithm="Ed25519", passphrase="secret-passphrase-123")
        payload = b"Confidential message."

        with self.assertRaises(ValueError):
            sign_bytes(private_pem=kp.private_pem, data=payload, passphrase="wrong-passphrase")

        with self.assertRaises(ValueError):
            sign_bytes(private_pem=kp.private_pem, data=payload, passphrase="")

    def test_07_binary_file_bytes_sign_and_verify(self) -> None:
        """Arbitrary non-UTF8 binary file bytes (e.g. PNG/PDF headers & random bytes) sign and verify properly."""
        kp = generate_keypair(algorithm="Ed25519")
        binary_payload = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR" + bytes(range(256))

        bundle = sign_bytes(
            private_pem=kp.private_pem,
            data=binary_payload,
            payload_type="file",
            filename="firmware_v2.bin",
        )
        self.assertEqual(bundle.payload_type, "file")
        self.assertEqual(bundle.filename, "firmware_v2.bin")

        verify_ok = verify_bytes(
            public_pem=kp.public_pem,
            data=binary_payload,
            signature_b64=bundle.signature_b64,
        )
        self.assertTrue(verify_ok.is_valid)

        # Flip 1 byte in the binary stream
        mutated_binary = binary_payload[:-1] + bytes([binary_payload[-1] ^ 0xFF])
        verify_fail = verify_bytes(
            public_pem=kp.public_pem,
            data=mutated_binary,
            signature_b64=bundle.signature_b64,
        )
        self.assertFalse(verify_fail.is_valid)

    def test_08_signature_bundle_json_roundtrip_and_validation(self) -> None:
        """SignatureBundle.to_json() and .from_json() preserve all fields and reject missing/invalid fields."""
        kp = generate_keypair(algorithm="Ed25519")
        bundle = sign_bytes(
            private_pem=kp.private_pem,
            data=b"Canonical JSON bundle test",
            payload_type="file",
            filename="release.tar.gz",
        )

        json_str = bundle.to_json()
        restored = SignatureBundle.from_json(json_str)
        self.assertEqual(bundle, restored)

        # Verify keys are canonically sorted
        parsed_keys = list(json.loads(json_str).keys())
        self.assertEqual(parsed_keys, sorted(parsed_keys))

        # Missing required field must raise ValueError
        incomplete_dict = json.loads(json_str)
        del incomplete_dict["signature_b64"]
        with self.assertRaises(ValueError):
            SignatureBundle.from_json(json.dumps(incomplete_dict))

    def test_09_cross_algorithm_key_mismatch_fails_cleanly(self) -> None:
        """Verifying an RSA-2048 signature against an Ed25519 public key (and vice versa) fails gracefully."""
        ed_kp = generate_keypair(algorithm="Ed25519")
        rsa_kp = generate_keypair(algorithm="RSA-2048")
        payload = b"Cross-algorithm verification check"

        ed_bundle = sign_bytes(private_pem=ed_kp.private_pem, data=payload)
        rsa_bundle = sign_bytes(private_pem=rsa_kp.private_pem, data=payload)

        res1 = verify_bytes(public_pem=rsa_kp.public_pem, data=payload, signature_b64=ed_bundle.signature_b64)
        self.assertFalse(res1.is_valid)

        res2 = verify_bytes(public_pem=ed_kp.public_pem, data=payload, signature_b64=rsa_bundle.signature_b64)
        self.assertFalse(res2.is_valid)


if __name__ == "__main__":
    unittest.main(verbosity=2)
