# Role & Objective

Act as a Senior Python Security Engineer and Streamlit UI Architect. Build a complete, modular, deploy-ready **Digital Signature Verification System** in Python using **Streamlit** and the official `cryptography` library. The app must be ready to push to GitHub and deploy directly to **Streamlit Community Cloud** with zero missing imports, zero placeholders, and full automated unit tests.

---

# Architecture & File Structure

Generate the following complete project structure with strict separation of concerns (the cryptographic core must have **zero** Streamlit imports so it can be unit-tested or reused in a CLI/FastAPI backend):

```text
digital-signature-system/
├── app.py                     # Streamlit web interface (4 tabs + sidebar)
├── crypto_core.py             # Pure Python cryptographic engine & dataclasses
├── requirements.txt           # Pinned dependencies for Streamlit Community Cloud
├── .streamlit/
│   └── config.toml            # Clean, modern visual theme
├── tests/
│   └── test_crypto_core.py    # Comprehensive unittest suite (8+ test cases)
└── README.md                  # Architecture, local setup, deployment & security notes
```

---

# Cryptographic Engine Requirements (`crypto_core.py`)

1. **Libraries:** Use only Python's standard library (`base64`, `hashlib`, `json`, `dataclasses`, `datetime`) and `cryptography` (`>=43.0.0`). Never implement custom cryptographic math or use deprecated libraries like `pycrypto`.
2. **Algorithms Supported:**
   - **Ed25519** (recommended default): fast, 32-byte keys, 64-byte deterministic detached signatures.
   - **RSA-2048**: `public_exponent=65537`, `key_size=2048`, signed and verified using `PSS` padding (`MGF1(SHA-256)`, `salt_length=PSS.MAX_LENGTH`) with `SHA-256`.
3. **Structured Dataclasses:**
   - `KeyPair`: `algorithm`, `private_pem`, `public_pem`, `fingerprint_sha256`, `encrypted`, `created_at` (UTC ISO-8601).
   - `SignatureBundle`: `algorithm`, `signature_b64`, `payload_sha256`, `public_key_fingerprint`, `signed_at`, `payload_type` (`"text"` or `"file"`), `filename` (optional), with canonical `.to_json()` (`sort_keys=True`) and `.from_json()` validation.
   - `VerificationResult`: `is_valid`, `algorithm`, `payload_sha256`, `public_key_fingerprint`, `reason`.
4. **Core Functions:**
   - `generate_keypair(algorithm, passphrase="") -> KeyPair`: Serialize private key as PEM (`PKCS8`, encrypted with `BestAvailableEncryption` if passphrase is provided, otherwise `NoEncryption`) and public key as PEM (`SubjectPublicKeyInfo`).
   - `public_key_fingerprint(public_pem) -> str`: Compute SHA-256 over the DER-encoded `SubjectPublicKeyInfo` and format as uppercase colon-separated 4-character hex groups.
   - `sign_bytes(private_pem, data, passphrase="", payload_type="text", filename=None) -> SignatureBundle`: Auto-detect whether the loaded private key is Ed25519 or RSA.
   - `verify_bytes(public_pem, data, signature_b64) -> VerificationResult`: Auto-detect key type; gracefully catch `InvalidSignature`, malformed Base64, invalid PEM, or mismatched key types and return a clear human-readable `reason` without crashing.
5. **Security & Privacy Rules:**
   - Process all keys and payloads strictly in memory—never write private keys or messages to disk or print them to logs.
   - Always sign and verify raw bytes (`UTF-8` encoded for text, raw bytes for uploaded files).

---

# Streamlit UI & UX Requirements (`app.py`)

1. **Page Layout & Security Disclaimer:**
   - Use `layout="wide"`, a crisp title, and a prominent top `st.warning` banner stating: *"Educational Demo: All cryptographic operations run strictly in memory and no keys are stored on disk. In production systems, signing must happen locally on the client device—do not upload real production private keys here."*
2. **Sidebar:**
   - **1-Click Quick-Start Demo Button:** Generates an ephemeral Ed25519 key pair in `st.session_state`, signs a realistic sample invoice message, and pre-populates the Verify tab so recruiters or evaluators can test signing and tampering in 10 seconds without uploading files.
   - **Active Session Key Card:** Displays algorithm, encryption status, and SHA-256 fingerprint of the currently loaded session key.
   - **In-Memory Session Activity Log:** Compact `st.dataframe` showing the last 20 operations (`Time UTC`, `Action`, `Algorithm`, `Key Fingerprint`, `Status`)—never log private keys, passphrases, or raw messages.
3. **Main Workspace (4 Tabs):**
   - **Tab 1 — Key Management:** Select `Ed25519` or `RSA-2048`, enter an optional passphrase, generate keys, display SHA-256 fingerprint, expandable public key PEM preview, and download buttons for `private_key.pem` and `public_key.pem`.
   - **Tab 2 — Sign Message / File:** Choose between active session key or uploading a `.pem` private key (with passphrase field); choose between text input or binary file upload; generate and display the Base64 detached signature, SHA-256 payload digest, timestamp metrics, and a download button for `<name>.sig.json`.
   - **Tab 3 — Verify & Tamper Test:** Choose active session public key or upload `public_key.pem`; choose text input or file upload; paste a Base64 signature or upload a `.sig.json` bundle; include a **1-Click "Simulate Tampering"** button on text mode that alters one character so anyone can watch verification flip from Valid to Invalid; display high-contrast green (`SIGNATURE VALID`) or red (`SIGNATURE INVALID / TAMPERED`) result banners along with algorithm, computed SHA-256 digest, and key fingerprint metrics.
   - **Tab 4 — How It Works & Architecture:** Concise visual overview of Authenticity, Integrity, and Non-repudiation, plus a side-by-side comparison table of Ed25519 vs. RSA-2048 (PSS + SHA-256) and a brief note on real-world PKI/certificate authorities.

---

# Testing & Deployment Requirements

1. **`tests/test_crypto_core.py`:** Include unit tests verifying:
   - Valid Ed25519 sign + verify (with passphrase encryption)
   - Valid RSA-2048 sign + verify
   - Single-byte message tampering fails for both algorithms
   - Wrong public key fails verification
   - Corrupted signature / invalid Base64 fails gracefully without raising an unhandled exception
   - Wrong passphrase raises `ValueError`
   - Binary file bytes sign + verify
   - `SignatureBundle` JSON serialization round-trip and missing-field validation
2. **`requirements.txt`:** Include only `cryptography>=43.0.0` and `streamlit>=1.38.0`.
3. **`.streamlit/config.toml`:** Define a clean, high-contrast modern theme (`primaryColor`, `backgroundColor`, `secondaryBackgroundColor`, `textColor`, `font`).
4. **`README.md`:** Include a project overview, ASCII/Mermaid architecture diagram, local run commands (`pip install -r requirements.txt`, `python -m unittest discover tests -v`, `streamlit run app.py`), Streamlit Community Cloud deployment steps, and a security trade-offs section (client-side vs. server-side signing).

---

# Output Instructions

- Output **every file completely** with clear file path headers (`### file: path/to/file`).
- Do **not** abbreviate code, skip error handling, or use placeholders like `# ... rest of code`.
- Ensure all type hints are compatible with Python 3.10+.
- Verify that `app.py` handles empty inputs, mismatched keys, and re-runs cleanly using `st.session_state`.
