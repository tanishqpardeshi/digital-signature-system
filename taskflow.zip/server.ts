import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer as createViteServer } from 'vite';
import {
  AlgorithmType,
  PayloadType,
  SignatureBundle,
  generateKeypair,
  signBytes,
  verifyBytes,
} from './src/crypto/crypto_core';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SAMPLE_INVOICE_TEXT = [
  'INVOICE #INV-2026-0842',
  'From: Aegis Cloud Security Ltd.',
  'To: Meridian Financial Holdings',
  'Amount Due: $48,500.00 USD',
  'Settlement IBAN: DE89-3704-0044-0532-0130-00',
  'Authorized By: Chief Information Security Officer',
  'Terms: Net-15 Wire Transfer — Immutable Cryptographic Audit Record',
].join('\n');

const STREAMLIT_BUNDLE_FILES = [
  'digital-signature-system/app.py',
  'digital-signature-system/crypto_core.py',
  'digital-signature-system/requirements.txt',
  'digital-signature-system/.streamlit/config.toml',
  'digital-signature-system/tests/test_crypto_core.py',
  'digital-signature-system/README.md',
] as const;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '25mb' }));

  app.post('/api/crypto/generate-keypair', (req, res) => {
    try {
      const algorithm: AlgorithmType = req.body?.algorithm === 'RSA-2048' ? 'RSA-2048' : 'Ed25519';
      const passphrase = typeof req.body?.passphrase === 'string' ? req.body.passphrase : '';
      const keypair = generateKeypair(algorithm, passphrase);
      res.json({ ok: true, keypair });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(400).json({ ok: false, error: message });
    }
  });

  app.post('/api/crypto/sign', (req, res) => {
    try {
      const privatePem = typeof req.body?.private_pem === 'string' ? req.body.private_pem : '';
      const passphrase = typeof req.body?.passphrase === 'string' ? req.body.passphrase : '';
      const payloadType: PayloadType = req.body?.payload_type === 'file' ? 'file' : 'text';
      const filename = typeof req.body?.filename === 'string' ? req.body.filename : null;

      let dataBuffer: Buffer;
      if (typeof req.body?.data_b64 === 'string') {
        dataBuffer = Buffer.from(req.body.data_b64, 'base64');
      } else if (typeof req.body?.text === 'string') {
        dataBuffer = Buffer.from(req.body.text, 'utf-8');
      } else {
        throw new Error('Provide either text or data_b64 payload.');
      }

      if (dataBuffer.length === 0) {
        throw new Error('Payload cannot be empty.');
      }

      const bundle = signBytes(privatePem, dataBuffer, passphrase, payloadType, filename);
      res.json({
        ok: true,
        bundle,
        bundle_json: bundle.toJson(),
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(400).json({ ok: false, error: message });
    }
  });

  app.post('/api/crypto/verify', (req, res) => {
    try {
      const publicPem = typeof req.body?.public_pem === 'string' ? req.body.public_pem : '';
      let signatureB64 = typeof req.body?.signature_b64 === 'string' ? req.body.signature_b64 : '';
      let bundleMetadata: SignatureBundle | null = null;

      if (typeof req.body?.bundle_json === 'string' && req.body.bundle_json.trim()) {
        bundleMetadata = SignatureBundle.fromJson(req.body.bundle_json);
        signatureB64 = bundleMetadata.signature_b64;
      }

      let dataBuffer: Buffer;
      if (typeof req.body?.data_b64 === 'string') {
        dataBuffer = Buffer.from(req.body.data_b64, 'base64');
      } else if (typeof req.body?.text === 'string') {
        dataBuffer = Buffer.from(req.body.text, 'utf-8');
      } else {
        dataBuffer = Buffer.alloc(0);
      }

      const result = verifyBytes(publicPem, dataBuffer, signatureB64);
      res.json({
        ok: true,
        result,
        bundle_metadata: bundleMetadata,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(400).json({ ok: false, error: message });
    }
  });

  app.post('/api/crypto/quick-start', (_req, res) => {
    try {
      const keypair = generateKeypair('Ed25519', '');
      const payloadBuffer = Buffer.from(SAMPLE_INVOICE_TEXT, 'utf-8');
      const bundle = signBytes(keypair.private_pem, payloadBuffer, '', 'text', 'invoice_2026_0842.txt');
      const verification = verifyBytes(keypair.public_pem, payloadBuffer, bundle.signature_b64);

      res.json({
        ok: true,
        sample_text: SAMPLE_INVOICE_TEXT,
        keypair,
        bundle,
        bundle_json: bundle.toJson(),
        verification,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(500).json({ ok: false, error: message });
    }
  });

  app.get('/api/project-files', (_req, res) => {
    try {
      const files = STREAMLIT_BUNDLE_FILES.map((relPath) => {
        const absPath = path.resolve(__dirname, relPath);
        const content = fs.existsSync(absPath) ? fs.readFileSync(absPath, 'utf-8') : '';
        return {
          path: relPath,
          filename: path.basename(relPath),
          content,
          lines: content.split('\n').length,
          bytes: Buffer.byteLength(content, 'utf-8'),
        };
      });
      res.json({ ok: true, files });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      res.status(500).json({ ok: false, error: message });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Digital Signature Verification System listening on http://localhost:${PORT}`);
  });
}

startServer();
